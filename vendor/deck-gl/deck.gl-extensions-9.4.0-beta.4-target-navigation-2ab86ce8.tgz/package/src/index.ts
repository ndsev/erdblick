// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors

export {default as BrushingExtension} from './brushing/brushing-extension';
export {default as DataFilterExtension} from './data-filter/data-filter-extension';
export {default as Fp64Extension} from './fp64/fp64-extension';
export {default as PathStyleExtension} from './path-style/path-style-extension';
export {default as FillStyleExtension} from './fill-style/fill-style-extension';
export {default as ClipExtension} from './clip/clip-extension';
export {default as CollisionFilterExtension} from './collision-filter/collision-filter-extension';
export {default as MaskExtension} from './mask/mask-extension';
export {default as _TerrainExtension} from './terrain/terrain-extension';

// Shader module
export {default as project64} from './fp64/project64';

// Types
export type {BrushingExtensionProps} from './brushing/brushing-extension';
export type {
  DataFilterExtensionProps,
  DataFilterExtensionOptions
} from './data-filter/data-filter-extension';
export type {
  PathStyleExtensionProps,
  PathStyleExtensionOptions,
  DashMode,
  DashUnits
} from './path-style/path-style-extension';
export type {
  FillStyleExtensionProps,
  FillStyleExtensionOptions
} from './fill-style/fill-style-extension';
export type {
  HatchPatternConfig,
  CrossHatchPatternConfig,
  DotPatternConfig,
  ProceduralPatternConfig,
  ProceduralPatternMapping
} from './fill-style/procedural-pattern';
export type {ClipExtensionProps} from './clip/clip-extension';
export type {CollisionFilterExtensionProps} from './collision-filter/collision-filter-extension';
export type {MaskExtensionProps} from './mask/mask-extension';
export type {TerrainExtensionProps} from './terrain/terrain-extension';
export type {TerrainModuleProps} from './terrain/shader-module';
