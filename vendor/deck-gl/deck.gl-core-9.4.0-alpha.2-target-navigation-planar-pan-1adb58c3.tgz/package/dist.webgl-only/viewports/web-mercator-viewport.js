// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
// View and Projection Matrix calculations for mapbox-js style
// map view properties
import Viewport from "./viewport.js";
import { pixelsToWorld, getViewMatrix, addMetersToLngLat, unitsPerMeter, getProjectionParameters, altitudeToFovy, fovyToAltitude, fitBounds, getBounds } from '@math.gl/web-mercator';
import { Matrix4, clamp, vec2 } from '@math.gl/core';
const MINIMUM_TARGET_SCALE = 32 * Number.EPSILON;
function isFiniteArray(values) {
    for (let index = 0; index < values.length; index++) {
        if (!Number.isFinite(values[index])) {
            return false;
        }
    }
    return true;
}
function hasStableInverse(matrix) {
    const values = matrix;
    if (!isFiniteArray(values)) {
        return false;
    }
    const determinant = matrix.determinant();
    if (!Number.isFinite(determinant) || determinant === 0) {
        return false;
    }
    const inverse = new Matrix4(matrix).invert();
    if (!isFiniteArray(inverse)) {
        return false;
    }
    // A dimensionless infinity-norm condition estimate is invariant to uniform matrix scaling.
    // Unlike comparing the determinant to the fourth power of the largest entry, it also does not
    // reject ordinary low-zoom view matrices or moderate model translations.
    const condition = matrixInfinityNorm(values) * matrixInfinityNorm(inverse);
    return Number.isFinite(condition) && condition <= 1 / MINIMUM_TARGET_SCALE;
}
/** Infinity norm (maximum absolute row sum) of a column-major 4x4 matrix. */
function matrixInfinityNorm(values) {
    let norm = 0;
    for (let row = 0; row < 4; row++) {
        let rowSum = 0;
        for (let column = 0; column < 4; column++) {
            rowSum += Math.abs(values[column * 4 + row]);
        }
        norm = Math.max(norm, rowSum);
    }
    return norm;
}
/** Returns the equivalent longitude nearest to a reference world copy. */
function normalizeLongitude(longitude, reference) {
    return longitude + 360 * Math.round((reference - longitude) / 360);
}
/**
 * Manages transformations to/from WGS84 coordinates using the Web Mercator Projection.
 */
class WebMercatorViewport extends Viewport {
    /* eslint-disable complexity, max-statements */
    constructor(opts = {}) {
        const { latitude = 0, longitude = 0, zoom = 0, pitch = 0, bearing = 0, nearZMultiplier = 0.1, farZMultiplier = 1.01, nearZ, farZ, orthographic = false, projectionMatrix, repeat = false, worldOffset = 0, position, padding, 
        // backward compatibility
        // TODO: remove in v9
        legacyMeterSizes = false } = opts;
        let { width, height, altitude = 1.5 } = opts;
        const scale = Math.pow(2, zoom);
        // Silently allow apps to send in 0,0 to facilitate isomorphic render etc
        width = width || 1;
        height = height || 1;
        let fovy;
        let projectionParameters = null;
        if (projectionMatrix) {
            altitude = projectionMatrix[5] / 2;
            fovy = altitudeToFovy(altitude);
        }
        else {
            if (opts.fovy) {
                fovy = opts.fovy;
                altitude = fovyToAltitude(fovy);
            }
            else {
                fovy = altitudeToFovy(altitude);
            }
            let offset;
            if (padding) {
                const { top = 0, bottom = 0 } = padding;
                offset = [0, clamp((top + height - bottom) / 2, 0, height) - height / 2];
            }
            projectionParameters = getProjectionParameters({
                width,
                height,
                scale,
                center: position && [0, 0, position[2] * unitsPerMeter(latitude)],
                offset,
                pitch,
                fovy,
                nearZMultiplier,
                farZMultiplier
            });
            if (Number.isFinite(nearZ)) {
                projectionParameters.near = nearZ;
            }
            if (Number.isFinite(farZ)) {
                projectionParameters.far = farZ;
            }
        }
        // The uncentered matrix allows us two move the center addition to the
        // shader (cheap) which gives a coordinate system that has its center in
        // the layer's center position. This makes rotations and other modelMatrx
        // transforms much more useful.
        let viewMatrixUncentered = getViewMatrix({
            height,
            pitch,
            bearing,
            scale,
            altitude
        });
        if (worldOffset) {
            const viewOffset = new Matrix4().translate([512 * worldOffset, 0, 0]);
            viewMatrixUncentered = viewOffset.multiplyLeft(viewMatrixUncentered);
        }
        super({
            ...opts,
            // x, y,
            width,
            height,
            // view matrix
            viewMatrix: viewMatrixUncentered,
            longitude,
            latitude,
            zoom,
            // projection matrix parameters
            ...projectionParameters,
            fovy,
            focalDistance: altitude
        });
        // Save parameters
        this.latitude = latitude;
        this.longitude = longitude;
        this.zoom = zoom;
        this.pitch = pitch;
        this.bearing = bearing;
        this.altitude = altitude;
        this.fovy = fovy;
        this.orthographic = orthographic;
        this._subViewports = repeat ? [] : null;
        this._pseudoMeters = legacyMeterSizes;
        this._hasCustomProjectionMatrix = Boolean(projectionMatrix);
        this._worldOffset = worldOffset;
        this._hasValidDimensions =
            (opts.width === undefined || (Number.isFinite(opts.width) && opts.width > 0)) &&
                (opts.height === undefined || (Number.isFinite(opts.height) && opts.height > 0));
        this.supportsTargetNavigation =
            !orthographic &&
                !this._hasCustomProjectionMatrix &&
                !this._pseudoMeters &&
                this._hasValidDimensions;
        Object.freeze(this);
    }
    /* eslint-enable complexity, max-statements */
    get subViewports() {
        if (this._subViewports && !this._subViewports.length) {
            // Cache sub viewports so that we only calculate them once
            const bounds = this.getBounds();
            const minOffset = Math.floor((bounds[0] + 180) / 360);
            const maxOffset = Math.ceil((bounds[2] - 180) / 360);
            for (let x = minOffset; x <= maxOffset; x++) {
                const offsetViewport = x
                    ? new WebMercatorViewport({
                        ...this,
                        worldOffset: x
                    })
                    : this;
                this._subViewports.push(offsetViewport);
            }
        }
        return this._subViewports;
    }
    projectPosition(xyz) {
        if (this._pseudoMeters) {
            // Backward compatibility
            return super.projectPosition(xyz);
        }
        const [X, Y] = this.projectFlat(xyz);
        const Z = (xyz[2] || 0) * unitsPerMeter(xyz[1]);
        return [X, Y, Z];
    }
    unprojectPosition(xyz) {
        if (this._pseudoMeters) {
            // Backward compatibility
            return super.unprojectPosition(xyz);
        }
        const [X, Y] = this.unprojectFlat(xyz);
        const Z = (xyz[2] || 0) / unitsPerMeter(Y);
        return [X, Y, Z];
    }
    /**
     * Add a meter delta to a base lnglat coordinate, returning a new lnglat array
     *
     * Note: Uses simple linear approximation around the viewport center
     * Error increases with size of offset (roughly 1% per 100km)
     *
     * @param {[Number,Number]|[Number,Number,Number]) lngLatZ - base coordinate
     * @param {[Number,Number]|[Number,Number,Number]) xyz - array of meter deltas
     * @return {[Number,Number]|[Number,Number,Number]) array of [lng,lat,z] deltas
     */
    addMetersToLngLat(lngLatZ, xyz) {
        return addMetersToLngLat(lngLatZ, xyz);
    }
    panByPosition(coords, pixel, startPixel) {
        const fromLocation = pixelsToWorld(pixel, this.pixelUnprojectionMatrix);
        const toLocation = this.projectFlat(coords);
        const translate = vec2.add([], toLocation, vec2.negate([], fromLocation));
        const newCenter = vec2.add([], this.center, translate);
        const [longitude, latitude] = this.unprojectFlat(newCenter);
        return { longitude, latitude };
    }
    /**
     * Returns an approximate longitude and latitude that moves a 3D world coordinate toward a
     * screen pixel. This compatibility helper applies one geographic-coordinate correction and can
     * retain visible error for nonzero viewport `position`; use `getTargetPanViewState` when a full,
     * exact target-relative planar map state is required.
     */
    panByPosition3D(coords, pixel) {
        const targetZ = coords[2] || 0;
        const deltaLngLat = vec2.sub([], coords, this.unproject(pixel, { targetZ }));
        return { longitude: this.longitude + deltaLngLat[0], latitude: this.latitude + deltaLngLat[1] };
    }
    /**
     * Reconstructs a canonical map state after translating the camera parallel to the world plane.
     *
     * Call this method on the frozen operation-start viewport. The target is placed at the supplied
     * view-local screen position by translating the viewport center in common-space X/Y only. Zoom,
     * bearing, pitch and common-space center Z are preserved; camera-to-target radius is deliberately
     * not preserved. The returned state must be rebuilt with the same dimensions, lens, padding,
     * clipping, model transform and world-copy configuration as this viewport.
     *
     * Returns `null` for unsupported projection modes, nonfinite/singular input, a target or desired
     * ray-plane intersection outside the camera clip volume, or an unrepresentable map state.
     */
    getTargetPanViewState(options) {
        const { target, screenPosition } = options;
        if (!isFiniteArray(screenPosition)) {
            return null;
        }
        const targetInfo = this.getTargetInfo(target);
        if (!targetInfo?.isValid) {
            return null;
        }
        try {
            const commonTarget = this.projectPosition(targetInfo.target);
            const intersectionXY = pixelsToWorld(screenPosition, this.pixelUnprojectionMatrix, commonTarget[2]);
            const commonIntersection = [intersectionXY[0], intersectionXY[1], commonTarget[2]];
            const intersectionView = new Matrix4(this.viewMatrix).transformAsPoint(commonIntersection);
            const intersectionDepth = -intersectionView[2];
            if (!isFiniteArray(commonTarget) ||
                !isFiniteArray(commonIntersection) ||
                !isFiniteArray(intersectionView) ||
                !Number.isFinite(intersectionDepth) ||
                Math.abs(commonIntersection[2] - commonTarget[2]) >
                    MINIMUM_TARGET_SCALE * Math.max(1, Math.abs(commonTarget[2])) ||
                intersectionDepth <= targetInfo.near ||
                intersectionDepth >= targetInfo.far) {
                return null;
            }
            const center = [
                this.center[0] + commonTarget[0] - commonIntersection[0],
                this.center[1] + commonTarget[1] - commonIntersection[1],
                this.center[2]
            ];
            return this._getTargetViewStateFromCenter(center, this.bearing, this.pitch, this.zoom);
        }
        catch {
            return null;
        }
    }
    /**
     * Returns camera-relative information about a target in the viewport's rendered world copy.
     *
     * The input longitude is not mutated. The returned `target` is a numeric copy whose longitude
     * is shifted by a multiple of 360 degrees when necessary to address the active repeated world.
     * Projected coordinates are view-local and do not include this viewport's canvas `x`/`y` offset.
     * Returns `null` for unsupported projection modes or invalid target coordinates.
     */
    getTargetInfo(target) {
        if (!this.supportsTargetNavigation ||
            target.length !== 3 ||
            !isFiniteArray(target) ||
            Math.abs(target[1]) >= 90) {
            return null;
        }
        try {
            const localizedTarget = [
                normalizeLongitude(target[0], this.longitude - this._worldOffset * 360),
                target[1],
                target[2]
            ];
            const commonPosition = this.projectPosition(localizedTarget);
            const projectedPosition = this.project(localizedTarget);
            const viewZ = this.viewMatrix[2] * commonPosition[0] +
                this.viewMatrix[6] * commonPosition[1] +
                this.viewMatrix[10] * commonPosition[2] +
                this.viewMatrix[14];
            const cameraDepth = -viewZ;
            const projection22 = this.projectionMatrix[10];
            const projection23 = this.projectionMatrix[14];
            const near = projection23 / (projection22 - 1);
            const far = projection23 / (projection22 + 1);
            // Freeze one isotropic local metric at the target. Web Mercator's local common-space scale
            // is conformal, so all three axes use the target latitude's meter conversion.
            const metersPerUnit = 1 / unitsPerMeter(localizedTarget[1]);
            const targetDistance = Math.hypot((commonPosition[0] - this.cameraPosition[0]) * metersPerUnit, (commonPosition[1] - this.cameraPosition[1]) * metersPerUnit, (commonPosition[2] - this.cameraPosition[2]) * metersPerUnit);
            const isFinite = isFiniteArray(commonPosition) &&
                isFiniteArray(projectedPosition) &&
                Number.isFinite(cameraDepth) &&
                Number.isFinite(near) &&
                Number.isFinite(far) &&
                Number.isFinite(targetDistance);
            const hasValidClipRange = isFinite && near > 0 && far > near;
            const isValid = hasValidClipRange &&
                cameraDepth > 0 &&
                projectedPosition[2] > -1 &&
                projectedPosition[2] < 1;
            const isVisible = isValid &&
                projectedPosition[0] >= 0 &&
                projectedPosition[0] <= this.width &&
                projectedPosition[1] >= 0 &&
                projectedPosition[1] <= this.height;
            return {
                target: localizedTarget,
                projectedPosition,
                targetDistance,
                cameraDepth,
                near,
                far,
                isValid,
                isVisible
            };
        }
        catch {
            return null;
        }
    }
    /**
     * Reconstructs a canonical perspective map state around a world-space target.
     *
     * Call this method on the frozen operation-start viewport. The target is placed at the supplied
     * view-local screen position, which may be outside the viewport. Its physical camera distance is
     * multiplied by
     * `2 ** (sourceZoom - requestedZoom)`, so omitting `zoom` produces a rigid orbit. The active
     * field of view, padding, clipping configuration, position/model transform, and world copy are
     * represented by the source viewport and must also be supplied when constructing the result.
     *
     * Returns `null` for orthographic or custom projections, nonfinite/singular input, a target
     * behind or outside the source camera's clip volume, or an unrepresentable map state.
     */
    getTargetViewState(options) {
        const { target, screenPosition } = options;
        const bearing = options.bearing ?? this.bearing;
        const pitch = options.pitch ?? this.pitch;
        const zoom = options.zoom ?? this.zoom;
        if (!isFiniteArray(screenPosition) || !isFiniteArray([bearing, pitch, zoom])) {
            return null;
        }
        const targetInfo = this.getTargetInfo(target);
        if (!targetInfo?.isValid) {
            return null;
        }
        try {
            const commonTarget = this.projectPosition(targetInfo.target);
            const sceneScale = Math.max(1, ...commonTarget.map(Math.abs), ...this.cameraPosition.map(Math.abs));
            const metersPerCommonUnit = 1 / unitsPerMeter(targetInfo.target[1]);
            const minimumTargetDistance = Math.max(MINIMUM_TARGET_SCALE * sceneScale * Math.abs(metersPerCommonUnit), targetInfo.near * Math.abs(metersPerCommonUnit) * 1e-9);
            if (!Number.isFinite(metersPerCommonUnit) ||
                targetInfo.targetDistance <= minimumTargetDistance) {
                return null;
            }
            const scale = Math.pow(2, zoom);
            if (!Number.isFinite(scale) || scale <= 0 || !Number.isFinite(this.altitude)) {
                return null;
            }
            // `pixelUnprojectionMatrix` incorporates the active perspective lens, padding and viewport
            // dimensions. Transforming an arbitrary point on its pixel ray back into view space removes
            // the source camera pose and leaves a direction from the camera origin through the requested
            // pixel. Keeping the source target's camera-space radius while replacing only that direction
            // preserves physical radius (scaled by zoom below) without retaining the source pixel.
            const sourceCameraTarget = new Matrix4(this.viewMatrix).transformAsPoint(commonTarget);
            const sourceCameraRadius = Math.hypot(...sourceCameraTarget);
            const unprojectedPixel = pixelsToWorld([screenPosition[0], screenPosition[1], 0.5], this.pixelUnprojectionMatrix);
            const commonRayPoint = unprojectedPixel.slice(0, 3);
            const cameraRay = new Matrix4(this.viewMatrix).transformAsPoint(commonRayPoint);
            const cameraRayLength = Math.hypot(...cameraRay);
            if (!isFiniteArray(sourceCameraTarget) ||
                !isFiniteArray(commonRayPoint) ||
                !isFiniteArray(cameraRay) ||
                !Number.isFinite(sourceCameraRadius) ||
                !Number.isFinite(cameraRayLength) ||
                sourceCameraRadius <= 0 ||
                cameraRayLength <= 0 ||
                cameraRay[2] >= 0) {
                return null;
            }
            const cameraTarget = cameraRay.map(component => (component * sourceCameraRadius) / cameraRayLength);
            const requestedViewMatrix = new Matrix4(getViewMatrix({
                height: this.height,
                pitch,
                bearing,
                scale,
                altitude: this.altitude
            }));
            if (!hasStableInverse(requestedViewMatrix)) {
                return null;
            }
            const uncenteredTarget = requestedViewMatrix.invert().transformAsPoint(cameraTarget);
            const center = [
                commonTarget[0] + 512 * this._worldOffset - uncenteredTarget[0],
                commonTarget[1] - uncenteredTarget[1],
                commonTarget[2] - uncenteredTarget[2]
            ];
            if (!isFiniteArray(center)) {
                return null;
            }
            return this._getTargetViewStateFromCenter(center, bearing, pitch, zoom);
        }
        catch {
            return null;
        }
    }
    /** Converts a common-space viewport center into the canonical public map-state fields. */
    _getTargetViewStateFromCenter(center, bearing, pitch, zoom) {
        if (!isFiniteArray(center) || !isFiniteArray([bearing, pitch, zoom])) {
            return null;
        }
        const [longitude, latitude] = this.unprojectFlat(center);
        const unitsPerMeterAtCenter = unitsPerMeter(latitude);
        if (!isFiniteArray([longitude, latitude, unitsPerMeterAtCenter]) ||
            Math.abs(latitude) >= 90 ||
            unitsPerMeterAtCenter <= 0) {
            return null;
        }
        let position = [0, 0, center[2] / unitsPerMeterAtCenter];
        if (this.modelMatrix) {
            const inverseModelMatrix = new Matrix4(this.modelMatrix);
            if (!hasStableInverse(inverseModelMatrix)) {
                return null;
            }
            position = Array.from(inverseModelMatrix.invert().transformAsVector(position));
        }
        if (!isFiniteArray(position)) {
            return null;
        }
        return {
            longitude,
            latitude,
            zoom,
            bearing,
            pitch,
            position: position
        };
    }
    getBounds(options = {}) {
        // @ts-ignore
        const corners = getBounds(this, options.z || 0);
        return [
            Math.min(corners[0][0], corners[1][0], corners[2][0], corners[3][0]),
            Math.min(corners[0][1], corners[1][1], corners[2][1], corners[3][1]),
            Math.max(corners[0][0], corners[1][0], corners[2][0], corners[3][0]),
            Math.max(corners[0][1], corners[1][1], corners[2][1], corners[3][1])
        ];
    }
    /**
     * Returns a new viewport that fit around the given rectangle.
     * Only supports non-perspective mode.
     */
    fitBounds(
    /** [[lon, lat], [lon, lat]] */
    bounds, options = {}) {
        const { width, height } = this;
        const { longitude, latitude, zoom } = fitBounds({ width, height, bounds, ...options });
        return new WebMercatorViewport({ width, height, longitude, latitude, zoom });
    }
}
WebMercatorViewport.displayName = 'WebMercatorViewport';
export default WebMercatorViewport;
//# sourceMappingURL=web-mercator-viewport.js.map