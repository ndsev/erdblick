// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
import { clamp } from '@math.gl/core';
import Controller from "./controller.js";
import ViewState from "./view-state.js";
import { getMaxBoundsExtents, getMaxBoundsRect } from "./utils.js";
import { worldToLngLat, lngLatToWorld as _lngLatToWorld } from '@math.gl/web-mercator';
import assert from "../utils/assert.js";
import { mod } from "../utils/math-utils.js";
import { deepEqual } from "../utils/deep-equal.js";
import LinearInterpolator from "../transitions/linear-interpolator.js";
import TargetNavigationInterpolator from "../transitions/target-navigation-interpolator.js";
import WebMercatorViewport from "../viewports/web-mercator-viewport.js";
const PITCH_MOUSE_THRESHOLD = 5;
const PITCH_ACCEL = 1.2;
const WEB_MERCATOR_TILE_SIZE = 512;
const WEB_MERCATOR_MAX_BOUNDS = [
    [-Infinity, -90],
    [Infinity, 90]
];
const TARGET_PIXEL_TOLERANCE = 0.1;
const TARGET_RADIUS_ABSOLUTE_TOLERANCE = 0.01;
const TARGET_RADIUS_RELATIVE_TOLERANCE = 1e-7;
const TARGET_NEAR_RELATIVE_EPSILON = 1e-6;
const TARGET_CENTER_Z_RELATIVE_TOLERANCE = 1e-10;
const TARGET_WHEEL_RELEASE_MS = 150;
function getTargetViewStructure(props) {
    const view = props._view;
    if (!view) {
        return null;
    }
    const viewProps = view.props || {};
    const projectionMatrix = viewProps.projectionMatrix;
    const modelMatrix = viewProps.modelMatrix ?? props['modelMatrix'];
    return {
        type: view.constructor,
        padding: viewProps.padding ? { ...viewProps.padding } : null,
        repeat: viewProps.repeat ?? false,
        nearZMultiplier: viewProps.nearZMultiplier ?? props['nearZMultiplier'] ?? 0.1,
        farZMultiplier: viewProps.farZMultiplier ?? props['farZMultiplier'] ?? 1.01,
        nearZ: viewProps.nearZ ?? props['nearZ'] ?? null,
        farZ: viewProps.farZ ?? props['farZ'] ?? null,
        projectionMatrix: projectionMatrix ? Array.from(projectionMatrix) : null,
        fovy: viewProps.fovy ?? props['fovy'] ?? null,
        altitude: viewProps.altitude ?? props.altitude ?? 1.5,
        orthographic: viewProps.orthographic ?? false,
        modelMatrix: modelMatrix ? Array.from(modelMatrix) : null,
        worldOffset: viewProps.worldOffset ?? props['worldOffset'] ?? 0
    };
}
/** The web mercator utility `lngLatToWorld` throws if invalid coordinates are provided.
 * This wrapper clamps user input to calculate common positions safely. */
function lngLatToWorld([lng, lat]) {
    if (Math.abs(lat) > 90) {
        lat = Math.sign(lat) * 90;
    }
    if (Number.isFinite(lng)) {
        const [x, y] = _lngLatToWorld([lng, lat]);
        return [x, clamp(y, 0, WEB_MERCATOR_TILE_SIZE)];
    }
    const [, y] = _lngLatToWorld([0, lat]);
    return [lng, clamp(y, 0, WEB_MERCATOR_TILE_SIZE)];
}
function copyTargetViewState(value) {
    if (!value ||
        !Number.isFinite(value.longitude) ||
        !Number.isFinite(value.latitude) ||
        !Number.isFinite(value.zoom) ||
        !Number.isFinite(value.bearing) ||
        !Number.isFinite(value.pitch) ||
        !Array.isArray(value.position) ||
        value.position.length !== 3 ||
        !value.position.every(Number.isFinite)) {
        return null;
    }
    return {
        longitude: value.longitude,
        latitude: value.latitude,
        zoom: value.zoom,
        bearing: value.bearing,
        pitch: value.pitch,
        position: [...value.position]
    };
}
function freezeTargetViewState(value) {
    return Object.freeze({
        ...value,
        position: Object.freeze([...value.position])
    });
}
/* Utils */
export class MapState extends ViewState {
    constructor(options) {
        const { 
        /** Mapbox viewport properties */
        /** The width of the viewport */
        width, 
        /** The height of the viewport */
        height, 
        /** The latitude at the center of the viewport */
        latitude, 
        /** The longitude at the center of the viewport */
        longitude, 
        /** The tile zoom level of the map. */
        zoom, 
        /** The bearing of the viewport in degrees */
        bearing = 0, 
        /** The pitch of the viewport in degrees */
        pitch = 0, 
        /**
         * Specify the altitude of the viewport camera
         * Unit: map heights, default 1.5
         * Non-public API, see https://github.com/mapbox/mapbox-gl-js/issues/1137
         */
        altitude = 1.5, 
        /** Viewport position */
        position = [0, 0, 0], 
        /** Viewport constraints */
        maxZoom = 20, minZoom = 0, maxPitch = 60, minPitch = 0, 
        /** Interaction states, required to calculate change during transform */
        /* The point on map being grabbed when the operation first started */
        startPanLngLat, 
        /* Center of the zoom when the operation first started */
        startZoomLngLat, 
        /* Pointer position when rotation started */
        startRotatePos, 
        /* The lng/lat point at the rotation pivot (where rotation started) */
        startRotateLngLat, 
        /** Bearing when current perspective rotate operation started */
        startBearing, 
        /** Pitch when current perspective rotate operation started */
        startPitch, 
        /** Zoom when current zoom operation started */
        startZoom, 
        /** Numeric target snapshot retained by the active target-navigation session */
        interactionTarget, 
        /** Canonical map state at target acquisition */
        targetNavigationStartProps, 
        /** Perspective viewport and target metrics frozen at acquisition */
        targetNavigationStartViewport, targetNavigationStartTargetInfo, 
        /** Controller-owned identity of the active target session */
        targetNavigationSessionId, 
        /** Target's desired pixel in the most recent accepted state */
        targetNavigationScreenPosition, 
        /** Raw input origin used to calculate absolute target-pan deltas */
        targetNavigationInputOrigin, 
        /** Application candidate policy frozen for this target session */
        targetNavigationConstraint, 
        /** View and input identity frozen for this target session */
        targetNavigationViewId, targetNavigationOperation, targetNavigationSource, 
        /** Normalize viewport props to fit map height into viewport */
        normalize = true } = options;
        assert(Number.isFinite(longitude)); // `longitude` must be supplied
        assert(Number.isFinite(latitude)); // `latitude` must be supplied
        assert(Number.isFinite(zoom)); // `zoom` must be supplied
        const maxBounds = options.maxBounds || (normalize ? WEB_MERCATOR_MAX_BOUNDS : null);
        const maxBoundsPadding = options.maxBoundsPadding || null;
        super({
            width,
            height,
            latitude,
            longitude,
            zoom,
            bearing,
            pitch,
            altitude,
            maxZoom,
            minZoom,
            maxPitch,
            minPitch,
            normalize,
            position,
            maxBounds,
            maxBoundsPadding
        }, {
            startPanLngLat,
            startZoomLngLat,
            startRotatePos,
            startRotateLngLat,
            startBearing,
            startPitch,
            startZoom,
            interactionTarget,
            targetNavigationStartProps,
            targetNavigationStartViewport,
            targetNavigationStartTargetInfo,
            targetNavigationSessionId,
            targetNavigationScreenPosition,
            targetNavigationInputOrigin,
            targetNavigationConstraint,
            targetNavigationViewId,
            targetNavigationOperation,
            targetNavigationSource
        }, options.makeViewport, options.constraintContext);
        this.getAltitude = options.getAltitude;
    }
    /** Returns a state carrying one immutable numeric interaction target. */
    withInteractionTarget(target, session) {
        const coordinate = Object.freeze([...target.coordinate]);
        const screenPosition = Object.freeze([...target.screenPosition]);
        const interactionTarget = Object.freeze({ coordinate, screenPosition });
        const targetNavigationStartViewport = this._getTargetViewport() || undefined;
        const startTargetInfo = targetNavigationStartViewport?.getTargetInfo(coordinate);
        const targetNavigationStartTargetInfo = startTargetInfo
            ? Object.freeze({
                ...startTargetInfo,
                target: Object.freeze([...startTargetInfo.target]),
                projectedPosition: Object.freeze([...startTargetInfo.projectedPosition])
            })
            : undefined;
        return this._getUpdatedState({
            interactionTarget,
            targetNavigationStartProps: { ...this.getViewportProps() },
            targetNavigationStartViewport,
            targetNavigationStartTargetInfo,
            targetNavigationSessionId: session?.sessionId,
            targetNavigationScreenPosition: [...screenPosition],
            targetNavigationInputOrigin: session?.inputOrigin
                ? [...session.inputOrigin]
                : [...screenPosition],
            targetNavigationConstraint: session?.constrainViewState,
            targetNavigationViewId: session?.viewId,
            targetNavigationOperation: session?.operation,
            targetNavigationSource: session?.source
        });
    }
    /** Returns a state without transient target-navigation bookkeeping. */
    withoutInteractionTarget() {
        return this._getUpdatedState({
            // A target session owns these gesture starts. Keeping any of them after a forced
            // cancellation would let a later stock move continue around the released 3D coordinate.
            startPanLngLat: null,
            startZoomLngLat: null,
            startZoom: null,
            startRotatePos: null,
            startRotateLngLat: null,
            startBearing: null,
            startPitch: null,
            interactionTarget: null,
            targetNavigationStartProps: null,
            targetNavigationStartViewport: null,
            targetNavigationStartTargetInfo: null,
            targetNavigationSessionId: null,
            targetNavigationScreenPosition: null,
            targetNavigationInputOrigin: null,
            targetNavigationConstraint: null,
            targetNavigationViewId: null,
            targetNavigationOperation: null,
            targetNavigationSource: null
        });
    }
    /**
     * Start panning
     * @param {[Number, Number]} pos - position on screen where the pointer grabs
     */
    panStart({ pos }, constraintContext) {
        return this._getUpdatedState({
            startPanLngLat: this._unproject(pos)
        }, constraintContext);
    }
    /**
     * Pan
     * @param {[Number, Number]} pos - position on screen where the pointer is
     * @param {[Number, Number], optional} startPos - where the pointer grabbed at
     *   the start of the operation. Must be supplied of `panStart()` was not called
     */
    pan({ pos, startPos }, constraintContext) {
        const state = this.getState();
        const interactionTarget = state.interactionTarget;
        if (interactionTarget) {
            const inputOrigin = state.targetNavigationInputOrigin || interactionTarget.screenPosition;
            const targetStartPosition = interactionTarget.screenPosition;
            return this._getTargetPanUpdatedState([
                targetStartPosition[0] + pos[0] - inputOrigin[0],
                targetStartPosition[1] + pos[1] - inputOrigin[1]
            ], constraintContext);
        }
        const startPanLngLat = state.startPanLngLat || this._unproject(startPos);
        if (!startPanLngLat) {
            return this;
        }
        const viewport = this.makeViewport(this.getViewportProps());
        const newProps = viewport.panByPosition(startPanLngLat, pos);
        return this._getUpdatedState(newProps, constraintContext);
    }
    /**
     * End panning
     * Must call if `panStart()` was called
     */
    panEnd(constraintContext) {
        return this._getUpdatedState({
            startPanLngLat: null
        }, constraintContext);
    }
    /**
     * Start rotating
     * @param {[Number, Number]} pos - position on screen where the center is
     */
    rotateStart({ pos }, constraintContext) {
        const interactionTarget = this.getState().interactionTarget;
        if (interactionTarget) {
            const targetInfo = this._getTargetViewport()?.getTargetInfo(interactionTarget.coordinate);
            return this._getUpdatedState({
                startRotatePos: pos,
                startRotateLngLat: targetInfo?.target || interactionTarget.coordinate,
                startBearing: this.getViewportProps().bearing,
                startPitch: this.getViewportProps().pitch
            }, constraintContext);
        }
        const altitude = this.getAltitude?.(pos);
        return this._getUpdatedState({
            startRotatePos: pos,
            startRotateLngLat: altitude !== undefined ? this._unproject3D(pos, altitude) : undefined,
            startBearing: this.getViewportProps().bearing,
            startPitch: this.getViewportProps().pitch
        }, constraintContext);
    }
    /**
     * Rotate
     * @param {[Number, Number]} pos - position on screen where the center is
     */
    rotate({ pos, deltaAngleX = 0, deltaAngleY = 0 }, constraintContext) {
        const { startRotatePos, startRotateLngLat, startBearing, startPitch } = this.getState();
        if (!startRotatePos || startBearing === undefined || startPitch === undefined) {
            return this;
        }
        let newRotation;
        if (pos) {
            newRotation = this._getNewRotation(pos, startRotatePos, startPitch, startBearing);
        }
        else {
            newRotation = {
                bearing: startBearing + deltaAngleX,
                pitch: startPitch + deltaAngleY
            };
        }
        // If we have a pivot point, adjust the camera position to keep the pivot point fixed
        if (startRotateLngLat) {
            if (this.getState().interactionTarget) {
                return this._getTargetPoseUpdatedState(newRotation, constraintContext);
            }
            const rotatedViewport = this.makeViewport({
                ...this.getViewportProps(),
                ...newRotation
            });
            // Use panByPosition3D if available (WebMercatorViewport), otherwise fall back to panByPosition
            const panMethod = 'panByPosition3D' in rotatedViewport ? 'panByPosition3D' : 'panByPosition';
            return this._getUpdatedState({
                ...newRotation,
                ...rotatedViewport[panMethod](startRotateLngLat, startRotatePos)
            }, constraintContext);
        }
        return this._getUpdatedState(newRotation, constraintContext);
    }
    /**
     * End rotating
     * Must call if `rotateStart()` was called
     */
    rotateEnd(constraintContext) {
        return this._getUpdatedState({
            startRotatePos: null,
            startRotateLngLat: null,
            startBearing: null,
            startPitch: null
        }, constraintContext);
    }
    /**
     * Start zooming
     * @param {[Number, Number]} pos - position on screen where the center is
     */
    zoomStart({ pos }, constraintContext) {
        return this._getUpdatedState({
            startZoomLngLat: this._unproject(pos),
            startZoom: this.getViewportProps().zoom
        }, constraintContext);
    }
    /**
     * Zoom
     * @param {[Number, Number]} pos - position on screen where the current center is
     * @param {[Number, Number]} startPos - the center position at
     *   the start of the operation. Must be supplied of `zoomStart()` was not called
     * @param {Number} scale - a number between [0, 1] specifying the accumulated
     *   relative scale.
     */
    zoom({ pos, startPos, scale }, constraintContext) {
        // Make sure we zoom around the current mouse position rather than map center
        let { startZoom, startZoomLngLat } = this.getState();
        if (this.getState().interactionTarget) {
            startZoom ?? (startZoom = this.getViewportProps().zoom);
            const zoom = this._constrainZoom(startZoom + Math.log2(scale));
            return this._getTargetPoseUpdatedState({ zoom }, constraintContext);
        }
        if (!startZoomLngLat) {
            // We have two modes of zoom:
            // scroll zoom that are discrete events (transform from the current zoom level),
            // and pinch zoom that are continuous events (transform from the zoom level when
            // pinch started).
            // If startZoom state is defined, then use the startZoom state;
            // otherwise assume discrete zooming
            startZoom = this.getViewportProps().zoom;
            startZoomLngLat = this._unproject(startPos) || this._unproject(pos);
        }
        if (!startZoomLngLat) {
            return this;
        }
        const zoom = this._constrainZoom(startZoom + Math.log2(scale));
        const zoomedViewport = this.makeViewport({ ...this.getViewportProps(), zoom });
        return this._getUpdatedState({
            zoom,
            ...zoomedViewport.panByPosition(startZoomLngLat, pos)
        }, constraintContext);
    }
    /** Applies the zoom and rotation components of one compound target gesture in one solve. */
    zoomRotate({ scale, deltaAngleX = 0, deltaAngleY = 0 }, constraintContext) {
        const { interactionTarget, startZoom, startBearing, startPitch } = this.getState();
        if (!interactionTarget ||
            startZoom === undefined ||
            startBearing === undefined ||
            startPitch === undefined) {
            return this;
        }
        return this._getTargetPoseUpdatedState({
            zoom: this._constrainZoom(startZoom + Math.log2(scale)),
            bearing: startBearing + deltaAngleX,
            pitch: startPitch + deltaAngleY
        }, constraintContext);
    }
    /**
     * End zooming
     * Must call if `zoomStart()` was called
     */
    zoomEnd(constraintContext) {
        return this._getUpdatedState({
            startZoomLngLat: null,
            startZoom: null
        }, constraintContext);
    }
    zoomIn(speed = 2, constraintContext) {
        return this._zoomFromCenter(speed, constraintContext);
    }
    zoomOut(speed = 2, constraintContext) {
        return this._zoomFromCenter(1 / speed, constraintContext);
    }
    moveLeft(speed = 100, constraintContext) {
        return this._panFromCenter([speed, 0], constraintContext);
    }
    moveRight(speed = 100, constraintContext) {
        return this._panFromCenter([-speed, 0], constraintContext);
    }
    moveUp(speed = 100, constraintContext) {
        return this._panFromCenter([0, speed], constraintContext);
    }
    moveDown(speed = 100, constraintContext) {
        return this._panFromCenter([0, -speed], constraintContext);
    }
    rotateLeft(speed = 15, constraintContext) {
        const bearing = this.getViewportProps().bearing - speed;
        return this.getState().interactionTarget
            ? this._getTargetPoseUpdatedState({ bearing }, constraintContext)
            : this._getUpdatedState({ bearing }, constraintContext);
    }
    rotateRight(speed = 15, constraintContext) {
        const bearing = this.getViewportProps().bearing + speed;
        return this.getState().interactionTarget
            ? this._getTargetPoseUpdatedState({ bearing }, constraintContext)
            : this._getUpdatedState({ bearing }, constraintContext);
    }
    rotateUp(speed = 10, constraintContext) {
        const pitch = this.getViewportProps().pitch + speed;
        return this.getState().interactionTarget
            ? this._getTargetPoseUpdatedState({ pitch }, constraintContext)
            : this._getUpdatedState({ pitch }, constraintContext);
    }
    rotateDown(speed = 10, constraintContext) {
        const pitch = this.getViewportProps().pitch - speed;
        return this.getState().interactionTarget
            ? this._getTargetPoseUpdatedState({ pitch }, constraintContext)
            : this._getUpdatedState({ pitch }, constraintContext);
    }
    shortestPathFrom(viewState) {
        // const endViewStateProps = new this.ControllerState(endProps).shortestPathFrom(startViewstate);
        const fromProps = viewState.getViewportProps();
        const props = { ...this.getViewportProps() };
        const { bearing, longitude } = props;
        if (Math.abs(bearing - fromProps.bearing) > 180) {
            props.bearing = bearing < 0 ? bearing + 360 : bearing - 360;
        }
        if (Math.abs(longitude - fromProps.longitude) > 180) {
            props.longitude = longitude < 0 ? longitude + 360 : longitude - 360;
        }
        return props;
    }
    // Apply any constraints (mathematical or defined by _viewportProps) to map state
    applyConstraints(props, _constraintContext) {
        // Ensure pitch is within specified range
        const { maxPitch, minPitch, pitch, longitude, bearing, normalize, maxBounds } = props;
        if (normalize) {
            if (longitude < -180 || longitude > 180) {
                props.longitude = mod(longitude + 180, 360) - 180;
            }
            if (bearing < -180 || bearing > 180) {
                props.bearing = mod(bearing + 180, 360) - 180;
            }
        }
        props.pitch = clamp(pitch, minPitch, maxPitch);
        props.zoom = this._constrainZoom(props.zoom, props);
        if (maxBounds) {
            const maxBoundsRect = getMaxBoundsRect(props.width, props.height, props.maxBoundsPadding);
            // Resolve the semantic center through the viewport because view padding can
            // place it away from the canvas' geometric center.
            const viewport = this.makeViewport({ ...props, bearing: 0, pitch: 0 });
            const screenExtents = getMaxBoundsExtents(viewport, [props.longitude, props.latitude], maxBoundsRect);
            const bl = lngLatToWorld(maxBounds[0]);
            const tr = lngLatToWorld(maxBounds[1]);
            // calculate center and zoom ranges at pitch=0 and bearing=0
            // to maintain visual stability when rotating
            const scale = 2 ** props.zoom;
            const [minLng, minLat] = worldToLngLat([
                bl[0] + screenExtents.left / scale,
                bl[1] + screenExtents.bottom / scale
            ]);
            const [maxLng, maxLat] = worldToLngLat([
                tr[0] - screenExtents.right / scale,
                tr[1] - screenExtents.top / scale
            ]);
            // A negative target dimension is inverted and therefore has no legal interval.
            if (maxBoundsRect.width >= 0) {
                props.longitude = clamp(props.longitude, minLng, maxLng);
            }
            if (maxBoundsRect.height >= 0) {
                props.latitude = clamp(props.latitude, minLat, maxLat);
            }
        }
        return props;
    }
    /* Private methods */
    _constrainZoom(zoom, props) {
        props || (props = this.getViewportProps());
        const { maxZoom, maxBounds } = props;
        const shouldApplyMaxBounds = maxBounds !== null && props.width > 0 && props.height > 0;
        let { minZoom } = props;
        if (shouldApplyMaxBounds) {
            const maxBoundsRect = getMaxBoundsRect(props.width, props.height, props.maxBoundsPadding);
            const bl = lngLatToWorld(maxBounds[0]);
            const tr = lngLatToWorld(maxBounds[1]);
            const w = tr[0] - bl[0];
            const h = tr[1] - bl[1];
            // ignore bound size of 0 or Infinity
            if (maxBoundsRect.width > 0 && Number.isFinite(w) && w > 0) {
                minZoom = Math.max(minZoom, Math.log2(maxBoundsRect.width / w));
            }
            if (maxBoundsRect.height > 0 && Number.isFinite(h) && h > 0) {
                minZoom = Math.max(minZoom, Math.log2(maxBoundsRect.height / h));
            }
            if (minZoom > maxZoom)
                minZoom = maxZoom;
        }
        return clamp(zoom, minZoom, maxZoom);
    }
    _zoomFromCenter(scale, constraintContext) {
        const targetScreenPosition = this.getState().targetNavigationScreenPosition;
        if (this.getState().interactionTarget && targetScreenPosition) {
            return this.zoom({ pos: targetScreenPosition, scale }, constraintContext);
        }
        const { width, height } = this.getViewportProps();
        return this.zoom({
            pos: [width / 2, height / 2],
            scale
        }, constraintContext);
    }
    _panFromCenter(offset, constraintContext) {
        const state = this.getState();
        const interactionTarget = state.interactionTarget;
        const targetScreenPosition = state.targetNavigationScreenPosition;
        if (interactionTarget && targetScreenPosition) {
            const screenPosition = [
                targetScreenPosition[0] + offset[0],
                targetScreenPosition[1] + offset[1]
            ];
            return this._getTargetPanUpdatedState(screenPosition, constraintContext);
        }
        const { width, height } = this.getViewportProps();
        return this.pan({
            startPos: [width / 2, height / 2],
            pos: [width / 2 + offset[0], height / 2 + offset[1]]
        }, constraintContext);
    }
    _getUpdatedState(newProps, constraintContext) {
        // @ts-ignore
        return new this.constructor({
            makeViewport: this.makeViewport,
            ...this.getViewportProps(),
            ...this.getState(),
            ...newProps,
            constraintContext
        });
    }
    /** Applies a target-aware planar translation using the frozen operation-start viewport. */
    _getTargetPanUpdatedState(screenPosition, constraintContext) {
        const state = this.getState();
        const sourceViewport = state.targetNavigationStartViewport;
        const sourceTargetInfo = state.targetNavigationStartTargetInfo;
        if (!state.interactionTarget || !sourceViewport || !sourceTargetInfo) {
            return this;
        }
        const requestedViewState = sourceViewport.getTargetPanViewState({
            target: sourceTargetInfo.target,
            screenPosition
        });
        if (!requestedViewState) {
            return this;
        }
        const constrainedViewState = this._applyTargetViewStateConstraint(requestedViewState, screenPosition);
        if (!constrainedViewState) {
            return this;
        }
        const candidate = this._getTargetUpdatedState(constrainedViewState, screenPosition, undefined, constraintContext);
        if (candidate === this) {
            return this;
        }
        const candidateViewport = candidate._getTargetViewport();
        if (!candidateViewport) {
            return this;
        }
        const centerZTolerance = TARGET_CENTER_Z_RELATIVE_TOLERANCE *
            Math.max(1, Math.abs(sourceViewport.center[2]), Math.abs(candidateViewport.center[2]));
        const bearingDelta = Math.abs(mod(candidateViewport.bearing - sourceViewport.bearing + 180, 360) - 180);
        if (Math.abs(candidateViewport.center[2] - sourceViewport.center[2]) > centerZTolerance ||
            Math.abs(candidateViewport.zoom - sourceViewport.zoom) > TARGET_CENTER_Z_RELATIVE_TOLERANCE ||
            Math.abs(candidateViewport.pitch - sourceViewport.pitch) >
                TARGET_CENTER_Z_RELATIVE_TOLERANCE ||
            bearingDelta > TARGET_CENTER_Z_RELATIVE_TOLERANCE) {
            return this;
        }
        return candidate;
    }
    /** Applies a target-relative pose using the frozen operation-start viewport. */
    _getTargetPoseUpdatedState(pose, constraintContext, expectedDistanceOverride, screenPositionOverride) {
        const state = this.getState();
        const interactionTarget = state.interactionTarget;
        const startProps = state.targetNavigationStartProps;
        const screenPosition = screenPositionOverride
            ? [...screenPositionOverride]
            : state.targetNavigationScreenPosition;
        if (!interactionTarget || !startProps || !screenPosition) {
            return this;
        }
        const currentProps = this.getViewportProps();
        const zoom = this._constrainZoom(pose.zoom ?? currentProps.zoom);
        const pitch = clamp(pose.pitch ?? currentProps.pitch, currentProps.minPitch, currentProps.maxPitch);
        const bearing = pose.bearing ?? currentProps.bearing;
        const sourceViewport = state.targetNavigationStartViewport;
        const sourceTargetInfo = state.targetNavigationStartTargetInfo;
        if (!sourceViewport || !sourceTargetInfo) {
            return this;
        }
        const targetViewState = sourceViewport.getTargetViewState({
            target: sourceTargetInfo.target,
            screenPosition,
            bearing,
            pitch,
            zoom
        });
        if (!targetViewState) {
            return this;
        }
        const constrainedViewState = this._applyTargetViewStateConstraint(targetViewState, screenPosition);
        if (!constrainedViewState) {
            return this;
        }
        const expectedDistance = expectedDistanceOverride
            ? expectedDistanceOverride * 2 ** (targetViewState.zoom - constrainedViewState.zoom)
            : sourceTargetInfo.targetDistance * 2 ** (startProps.zoom - constrainedViewState.zoom);
        return this._getTargetUpdatedState(constrainedViewState, screenPosition, expectedDistance, constraintContext);
    }
    /** Applies the application target policy before ordinary MapState constraints. */
    _applyTargetViewStateConstraint(requestedViewState, screenPosition) {
        const state = this.getState();
        const interactionTarget = state.interactionTarget;
        const sourceViewport = state.targetNavigationStartViewport;
        if (!interactionTarget || !sourceViewport) {
            return null;
        }
        if (!state.targetNavigationConstraint) {
            return requestedViewState;
        }
        const candidateTarget = Object.freeze({
            coordinate: interactionTarget.coordinate,
            screenPosition: Object.freeze([...screenPosition])
        });
        const applicationViewState = state.targetNavigationConstraint(Object.freeze({
            viewId: state.targetNavigationViewId || '',
            operation: state.targetNavigationOperation || 'zoom',
            source: state.targetNavigationSource || 'pointer',
            target: candidateTarget,
            sourceViewport,
            currentViewState: freezeTargetViewState(this._toTargetViewState(this.getViewportProps())),
            requestedViewState: freezeTargetViewState(requestedViewState)
        }));
        return applicationViewState && copyTargetViewState(applicationViewState);
    }
    _toTargetViewState(props) {
        return {
            longitude: props.longitude,
            latitude: props.latitude,
            zoom: props.zoom,
            bearing: props.bearing,
            pitch: props.pitch,
            position: [...props.position]
        };
    }
    /** Applies ordinary constraints, then validates target-relative camera invariants. */
    _getTargetUpdatedState(newProps, screenPosition, expectedDistance, constraintContext) {
        const interactionTarget = this.getState().interactionTarget;
        if (!interactionTarget) {
            return this._getUpdatedState(newProps, constraintContext);
        }
        const candidate = this._getUpdatedState({ ...newProps, targetNavigationScreenPosition: [...screenPosition] }, constraintContext);
        const viewport = candidate._getTargetViewport();
        const targetInfo = viewport?.getTargetInfo(interactionTarget.coordinate);
        if (!targetInfo?.isValid ||
            targetInfo.cameraDepth < targetInfo.near * (1 + TARGET_NEAR_RELATIVE_EPSILON)) {
            return this;
        }
        const pixelError = Math.hypot(targetInfo.projectedPosition[0] - screenPosition[0], targetInfo.projectedPosition[1] - screenPosition[1]);
        if (!Number.isFinite(pixelError) || pixelError > TARGET_PIXEL_TOLERANCE) {
            return this;
        }
        if (expectedDistance !== undefined) {
            const radiusTolerance = Math.max(TARGET_RADIUS_ABSOLUTE_TOLERANCE, TARGET_RADIUS_RELATIVE_TOLERANCE * expectedDistance);
            if (!Number.isFinite(expectedDistance) ||
                Math.abs(targetInfo.targetDistance - expectedDistance) > radiusTolerance) {
                return this;
            }
        }
        return candidate;
    }
    /** Returns a supported perspective Web Mercator viewport for target operations. */
    _getTargetViewport(props = this.getViewportProps()) {
        const viewport = this.makeViewport(props);
        return viewport instanceof WebMercatorViewport && viewport.supportsTargetNavigation
            ? viewport
            : null;
    }
    _unproject(pos) {
        const viewport = this.makeViewport(this.getViewportProps());
        // @ts-ignore
        return pos && viewport.unproject(pos);
    }
    _unproject3D(pos, altitude) {
        const viewport = this.makeViewport(this.getViewportProps());
        return viewport.unproject(pos, { targetZ: altitude });
    }
    _getNewRotation(pos, startPos, startPitch, startBearing) {
        const deltaX = pos[0] - startPos[0];
        const deltaY = pos[1] - startPos[1];
        const centerY = pos[1];
        const startY = startPos[1];
        const { width, height } = this.getViewportProps();
        const deltaScaleX = deltaX / width;
        let deltaScaleY = 0;
        if (deltaY > 0) {
            if (Math.abs(height - startY) > PITCH_MOUSE_THRESHOLD) {
                // Move from 0 to -1 as we drag upwards
                deltaScaleY = (deltaY / (startY - height)) * PITCH_ACCEL;
            }
        }
        else if (deltaY < 0) {
            if (startY > PITCH_MOUSE_THRESHOLD) {
                // Move from 0 to 1 as we drag upwards
                deltaScaleY = 1 - centerY / startY;
            }
        }
        // clamp deltaScaleY to [-1, 1] so that rotation is constrained between minPitch and maxPitch.
        // deltaScaleX does not need to be clamped as bearing does not have constraints.
        deltaScaleY = clamp(deltaScaleY, -1, 1);
        const { minPitch, maxPitch } = this.getViewportProps();
        const bearing = startBearing + 180 * deltaScaleX;
        let pitch = startPitch;
        if (deltaScaleY > 0) {
            // Gradually increase pitch
            pitch = startPitch + deltaScaleY * (maxPitch - startPitch);
        }
        else if (deltaScaleY < 0) {
            // Gradually decrease pitch
            pitch = startPitch - deltaScaleY * (minPitch - startPitch);
        }
        return {
            pitch,
            bearing
        };
    }
}
export default class MapController extends Controller {
    constructor() {
        super(...arguments);
        this.ControllerState = MapState;
        this.transition = {
            transitionDuration: 300,
            transitionInterpolator: new LinearInterpolator({
                transitionProps: {
                    compare: ['longitude', 'latitude', 'zoom', 'bearing', 'pitch', 'position'],
                    required: ['longitude', 'latitude', 'zoom']
                }
            })
        };
        this.dragMode = 'pan';
        /**
         * Rotation pivot behavior:
         * - 'center': Rotate around viewport center (default)
         * - '2d': Rotate around pointer position at ground level (z=0)
         * - '3d': Rotate around 3D picked point (requires pickPosition callback)
         */
        this.rotationPivot = 'center';
        this.targetNavigation = false;
        this._activeTarget = null;
        this._activeTargetOwners = new Set();
        this._wheelTargetTimer = null;
        this._targetSessionGeneration = 0;
        this._configurationRevision = 0;
        this._targetConstraintDepth = 0;
        this._activeTargetViewStructure = null;
        /** Add altitude to rotateStart params based on rotationPivot mode */
        this._getAltitude = (pos) => {
            if (this.rotationPivot === '2d') {
                return 0;
            }
            else if (this.rotationPivot === '3d') {
                if (this.pickPosition) {
                    const { x, y } = this.props;
                    const pickResult = this.pickPosition(x + pos[0], y + pos[1]);
                    if (pickResult && pickResult.coordinate && pickResult.coordinate.length >= 3) {
                        return pickResult.coordinate[2];
                    }
                }
            }
            return undefined;
        };
    }
    setProps(props) {
        if (this._targetConstraintDepth > 0) {
            throw new Error('MapController.setProps cannot be called synchronously from constrainInteractionTargetViewState');
        }
        this._configurationRevision++;
        this.rotationPivot = props.rotationPivot || 'center';
        const wasEnabled = this.targetNavigation;
        this.targetNavigation = props._targetNavigation ?? false;
        this.getInteractionTarget = props.getInteractionTarget;
        this.constrainInteractionTargetViewState = props.constrainInteractionTargetViewState;
        if (wasEnabled && !this.targetNavigation) {
            this._releaseAllTargets(true);
        }
        // this will be passed to MapState constructor
        props.getAltitude = this._getAltitude;
        props.position = props.position || [0, 0, 0];
        props.maxBounds =
            props.maxBounds || (props.normalize === false ? null : WEB_MERCATOR_MAX_BOUNDS);
        if (this._activeTarget &&
            (!this._areTargetViewportDimensionsEqual(props) ||
                !deepEqual(this._activeTargetViewStructure, getTargetViewStructure(props), -1))) {
            this._releaseAllTargets(true);
        }
        super.setProps(props);
        if (!this.targetNavigation) {
            this._cancelTargetTransition();
        }
    }
    updateViewport(newControllerState, extraProps = null, interactionState = {}) {
        const targetSessionId = newControllerState.getState().targetNavigationSessionId;
        if (targetSessionId !== undefined &&
            targetSessionId !== null &&
            (targetSessionId !== this._targetSessionGeneration || !this._activeTarget)) {
            return;
        }
        extraProps = this._getTargetTransitionProps(newControllerState, extraProps);
        // Publish only the numeric target coordinate. Applications retain any semantic identity.
        const state = newControllerState.getState();
        if (state.interactionTarget) {
            interactionState = {
                ...interactionState,
                interactionTargetPosition: [...state.interactionTarget.coordinate]
            };
            const isTargetRotation = (this._activeTargetOwners.has('rotate') && interactionState.isDragging !== false) ||
                (state.targetNavigationOperation === 'rotate' && interactionState.isRotating === true);
            if (isTargetRotation) {
                interactionState.rotationPivotPosition = [...state.interactionTarget.coordinate];
            }
            else {
                interactionState.rotationPivotPosition = undefined;
            }
        }
        else if (interactionState.isDragging && state.startRotateLngLat) {
            // Retain the established rotation-pivot field for compatibility when target navigation is
            // not active.
            interactionState = {
                ...interactionState,
                rotationPivotPosition: state.startRotateLngLat
            };
        }
        else if (interactionState.isDragging === false) {
            // Clear pivot when drag ends
            interactionState = { ...interactionState, rotationPivotPosition: undefined };
        }
        super.updateViewport(newControllerState, extraProps, interactionState);
    }
    finalize() {
        this._releaseAllTargets(true);
        super.finalize();
    }
    handleEvent(event) {
        try {
            return super.handleEvent(event);
        }
        catch (error) {
            this._releaseAllTargets(true);
            throw error;
        }
    }
    updateTransition() {
        try {
            super.updateTransition();
        }
        catch (error) {
            this._releaseAllTargets(true);
            throw error;
        }
    }
    /** Resolves one fresh numeric target. A configured provider is authoritative. */
    resolveInteractionTarget(screenPosition, operation, source) {
        // Elastic MapState constraints require a separate target-aware rebound definition. Until that
        // contract is implemented, preserve the complete stock rubber-band lifecycle.
        if (!this.targetNavigation || this.props.rubberBand) {
            return null;
        }
        const viewport = this.makeViewport(this.props);
        if (!(viewport instanceof WebMercatorViewport) || !viewport.supportsTargetNavigation) {
            return null;
        }
        const configurationRevision = this._configurationRevision;
        const provider = this.getInteractionTarget;
        let resolved = null;
        if (provider) {
            resolved = provider({
                viewId: this.props.id,
                operation,
                source,
                screenPosition: screenPosition && [...screenPosition],
                viewport
            });
        }
        else if (screenPosition && this.pickPosition) {
            const picked = this.pickPosition(this.props.x + screenPosition[0], this.props.y + screenPosition[1]);
            if (picked?.coordinate && picked.coordinate.length >= 3) {
                resolved = {
                    coordinate: picked.coordinate.slice(0, 3),
                    screenPosition: [...screenPosition]
                };
            }
        }
        if (configurationRevision !== this._configurationRevision ||
            !this.targetNavigation ||
            provider !== this.getInteractionTarget) {
            return null;
        }
        return this._copyValidTarget(resolved, viewport);
    }
    /** Whether target navigation currently owns an acquired numeric coordinate. */
    hasActiveInteractionTarget() {
        return Boolean(this._activeTarget);
    }
    _onPanStart(event) {
        const currentPosition = this.getCenter(event);
        const acquisitionPosition = this._getGestureAcquisitionPosition(event);
        if (!this._isTargetPositionInBounds(currentPosition) ||
            !this._isTargetPositionInBounds(acquisitionPosition) ||
            event.handled) {
            return false;
        }
        let alternateMode = this.isFunctionKeyPressed(event) || event.rightButton || false;
        if (this.invertPan || this.dragMode === 'pan') {
            alternateMode = !alternateMode;
        }
        const operation = alternateMode ? 'pan' : 'rotate';
        const sourceEnabled = event.pointerType !== 'trackpad' || this.trackpadGesture;
        if (sourceEnabled &&
            ((operation === 'pan' && this.dragPan) || (operation === 'rotate' && this.dragRotate))) {
            const source = event.pointerType === 'trackpad'
                ? 'trackpad'
                : event.pointerType === 'touch'
                    ? 'touch'
                    : 'pointer';
            this._acquireTarget(operation, source, acquisitionPosition);
        }
        return super._onPanStart(event);
    }
    _onPanMoveEnd(event) {
        const handled = super._onPanMoveEnd(event);
        if (handled) {
            if (this._activeTarget && this.transitionManager.transition.inProgress) {
                this._activeTargetOwners.add('transition');
            }
            this._releaseTargetOwner('pan');
        }
        return handled;
    }
    _onPanRotateEnd(event) {
        const handled = super._onPanRotateEnd(event);
        if (handled) {
            if (this._activeTarget && this.transitionManager.transition.inProgress) {
                this._activeTargetOwners.add('transition');
            }
            this._releaseTargetOwner('rotate');
        }
        return handled;
    }
    _onMultiPanStart(event) {
        const currentPos = this.getCenter(event);
        const isTrackpad = event.pointerType === 'trackpad';
        const pos = this._getGestureAcquisitionPosition(event);
        const modeEnabled = this.multiTouchDrag === 'pan'
            ? this.dragPan
            : this.multiTouchDrag === 'rotate' && this.dragRotate;
        const sourceEnabled = event.pointerType === 'touch' || (event.pointerType === 'trackpad' && this.trackpadGesture);
        if (sourceEnabled &&
            modeEnabled &&
            this._isTargetPositionInBounds(currentPos) &&
            this._isTargetPositionInBounds(pos) &&
            !event.handled) {
            this._acquireTarget(this.multiTouchDrag, isTrackpad ? 'trackpad' : 'touch', pos);
        }
        return super._onMultiPanStart(event);
    }
    _onPinchStart(event) {
        const pos = this.getCenter(event);
        const source = event.pointerType === 'trackpad' ? 'trackpad' : 'touch';
        const owners = [
            ...(this.touchZoom ? ['zoom'] : []),
            ...(this.touchRotate ? ['rotate'] : [])
        ];
        let acquired = false;
        if (owners.length > 0 && this._isTargetPositionInBounds(pos) && !event.handled) {
            this._acquireTarget('pinch', source, pos, owners);
            acquired = Boolean(this._activeTarget);
        }
        const handled = super._onPinchStart(event);
        if (!handled && acquired) {
            this._releaseAllTargets(true);
        }
        return handled;
    }
    _onPinch(event) {
        if (!this._activeTarget || !this.touchZoom || !this.touchRotate) {
            return super._onPinch(event);
        }
        if (!this.isDragging()) {
            return false;
        }
        const newControllerState = this.controllerState.zoomRotate({
            scale: event.scale,
            deltaAngleX: (this._startPinchRotation || 0) - event.rotation
        }, this._getConstraintContext('zoom', 'update'));
        this.updateViewport(newControllerState, { transitionDuration: 0 }, {
            isDragging: true,
            isPanning: true,
            isZooming: true,
            isRotating: true
        });
        this._lastPinchEvent = event;
        return true;
    }
    _onPinchEnd(event) {
        const handled = super._onPinchEnd(event);
        if (handled) {
            if (this._activeTarget && this.transitionManager.transition.inProgress) {
                this._activeTargetOwners.add('transition');
            }
            this._releaseTargetOwner('zoom');
            this._releaseTargetOwner('rotate');
        }
        return handled;
    }
    _onDoubleClickDragStart(event) {
        const pos = this.getCenter(event);
        if (this.doubleClickDragZoom && this._isTargetPositionInBounds(pos) && !event.handled) {
            this._acquireTarget('zoom', 'doubleClick', pos);
        }
        return super._onDoubleClickDragStart(event);
    }
    _onDoubleClickDragEnd(event) {
        const handled = super._onDoubleClickDragEnd(event);
        if (handled) {
            if (this._activeTarget && this.transitionManager.transition.inProgress) {
                this._activeTargetOwners.add('transition');
            }
            this._releaseTargetOwner('zoom');
        }
        return handled;
    }
    _onWheel(event) {
        if (this.scrollZoom && !(this.trackpadGesture && event.device !== 'mouse')) {
            const pos = this.getCenter(event);
            if (this._isTargetPositionInBounds(pos) && !event.handled) {
                this._acquireWheelTarget(pos);
            }
        }
        return super._onWheel(event);
    }
    _onDoubleClick(event) {
        const pos = this.getCenter(event);
        if (this.doubleClickZoom &&
            Date.now() >= this._suppressDoubleClickUntil &&
            this._isTargetPositionInBounds(pos) &&
            !event.handled) {
            this._acquireTarget('zoom', 'doubleClick', pos, ['transition']);
        }
        const handled = super._onDoubleClick(event);
        if (!handled || !this.transitionManager.transition.inProgress) {
            this._releaseTargetOwner('transition');
        }
        return handled;
    }
    _onKeyDown(event) {
        if (!this.keyboard) {
            return super._onKeyDown(event);
        }
        const code = event.srcEvent.code;
        if (code !== 'Minus' &&
            code !== 'Equal' &&
            code !== 'ArrowLeft' &&
            code !== 'ArrowRight' &&
            code !== 'ArrowUp' &&
            code !== 'ArrowDown') {
            return super._onKeyDown(event);
        }
        const operation = code === 'Minus' || code === 'Equal'
            ? 'zoom'
            : this.isFunctionKeyPressed(event)
                ? 'rotate'
                : 'pan';
        const target = this._acquireTarget(operation, 'keyboard', null, ['transition']);
        let handled;
        if (target && (code === 'Minus' || code === 'Equal') && this.isFunctionKeyPressed(event)) {
            const { zoomSpeed = 2 } = this.keyboard === true ? {} : this.keyboard;
            const speed = zoomSpeed * zoomSpeed;
            const newControllerState = code === 'Minus' ? this.controllerState.zoomOut(speed) : this.controllerState.zoomIn(speed);
            this.updateViewport(newControllerState, this._getTransitionProps(), { isZooming: true });
            handled = true;
        }
        else {
            handled = super._onKeyDown(event);
        }
        if (!handled || !this.transitionManager.transition.inProgress) {
            this._releaseTargetOwner('transition');
        }
        return handled;
    }
    _copyValidTarget(target, viewport) {
        if (!target ||
            !Array.isArray(target.coordinate) ||
            target.coordinate.length !== 3 ||
            !target.coordinate.every(Number.isFinite) ||
            !Array.isArray(target.screenPosition) ||
            target.screenPosition.length !== 2 ||
            !target.screenPosition.every(Number.isFinite)) {
            return null;
        }
        const targetInfo = viewport.getTargetInfo(target.coordinate);
        if (!targetInfo?.isVisible ||
            targetInfo.cameraDepth < targetInfo.near * (1 + TARGET_NEAR_RELATIVE_EPSILON)) {
            return null;
        }
        const pixelError = Math.hypot(targetInfo.projectedPosition[0] - target.screenPosition[0], targetInfo.projectedPosition[1] - target.screenPosition[1]);
        if (pixelError > TARGET_PIXEL_TOLERANCE) {
            return null;
        }
        return {
            coordinate: [...targetInfo.target],
            screenPosition: [...target.screenPosition]
        };
    }
    _isTargetPositionInBounds(pos) {
        return pos[0] >= 0 && pos[0] <= this.props.width && pos[1] >= 0 && pos[1] <= this.props.height;
    }
    /** Returns the pointer/touch origin, or the first recognized trackpad sample. */
    _getGestureAcquisitionPosition(event) {
        if (event.pointerType === 'trackpad') {
            return this.getCenter(event);
        }
        const deltaX = Number.isFinite(event.deltaX) ? event.deltaX : 0;
        const deltaY = Number.isFinite(event.deltaY) ? event.deltaY : 0;
        return this.getCenter({
            ...event,
            offsetCenter: {
                x: event.offsetCenter.x - deltaX,
                y: event.offsetCenter.y - deltaY
            }
        });
    }
    _acquireTarget(operation, source, screenPosition, owners = [
        operation === 'pinch' ? 'zoom' : operation
    ]) {
        if (this._activeTarget) {
            const reuseActiveTarget = owners.length === 1 && owners[0] === 'wheel' && this._activeTargetOwners.has('wheel');
            if (reuseActiveTarget) {
                for (const owner of owners)
                    this._activeTargetOwners.add(owner);
                return this._activeTarget;
            }
            // An active transition is a completed input session. A new gesture must acquire a fresh
            // scene target; only an explicitly continued wheel burst may reuse its frozen snapshot.
            this._releaseAllTargets(true);
        }
        try {
            const configurationRevision = this._configurationRevision;
            const target = this.resolveInteractionTarget(screenPosition, operation, source);
            if (!target ||
                !this.targetNavigation ||
                configurationRevision !== this._configurationRevision) {
                return null;
            }
            this._activeTarget = target;
            this._targetSessionGeneration++;
            this._activeTargetViewStructure = getTargetViewStructure(this.props);
            for (const owner of owners)
                this._activeTargetOwners.add(owner);
            this._installTargetState(target, operation, source, screenPosition);
            return target;
        }
        catch (error) {
            this._releaseAllTargets(true);
            this._setInteractionState({
                interactionTargetPosition: undefined,
                rotationPivotPosition: undefined
            });
            throw error;
        }
    }
    _acquireWheelTarget(screenPosition) {
        if (this._activeTargetOwners.has('wheel')) {
            this._acquireTarget('zoom', 'wheel', screenPosition, ['wheel']);
        }
        else {
            this._acquireTarget('zoom', 'wheel', screenPosition, ['wheel']);
        }
        if (this._activeTarget) {
            this._activeTargetOwners.add('transition');
        }
        if (this._wheelTargetTimer) {
            clearTimeout(this._wheelTargetTimer);
        }
        this._wheelTargetTimer = setTimeout(() => {
            this._wheelTargetTimer = null;
            this._releaseTargetOwner('wheel');
            if (!this.transitionManager.transition.inProgress) {
                this._releaseTargetOwner('transition');
            }
        }, TARGET_WHEEL_RELEASE_MS);
        return this._activeTarget;
    }
    _installTargetState(target, operation, source, inputOrigin) {
        const constraint = this.constrainInteractionTargetViewState;
        const state = this.controllerState.withInteractionTarget(target, {
            viewId: this.props.id,
            operation,
            source,
            sessionId: this._targetSessionGeneration,
            inputOrigin,
            constrainViewState: constraint
                ? context => {
                    this._targetConstraintDepth++;
                    try {
                        return constraint(context);
                    }
                    finally {
                        this._targetConstraintDepth--;
                    }
                }
                : undefined
        });
        this.state = state.getState();
        this._controllerState = state;
        this._setInteractionState({ interactionTargetPosition: [...target.coordinate] });
    }
    _releaseTargetOwner(owner) {
        this._activeTargetOwners.delete(owner);
        if (this._activeTargetOwners.size === 0) {
            this._clearTargetState();
        }
    }
    _releaseAllTargets(cancelTransition = false) {
        if (cancelTransition) {
            this._cancelTargetTransition();
        }
        if (this._wheelTargetTimer) {
            clearTimeout(this._wheelTargetTimer);
            this._wheelTargetTimer = null;
        }
        this._activeTargetOwners.clear();
        this._clearTargetState(cancelTransition);
    }
    _clearTargetState(cancelInteraction = false) {
        if (!this._activeTarget) {
            return;
        }
        this._activeTarget = null;
        this._activeTargetViewStructure = null;
        this._targetSessionGeneration++;
        const state = this.controllerState.withoutInteractionTarget();
        this.state = state.getState();
        this._controllerState = state;
        this._setInteractionState({
            interactionTargetPosition: undefined,
            rotationPivotPosition: undefined,
            ...(cancelInteraction
                ? {
                    isDragging: false,
                    isPanning: false,
                    isZooming: false,
                    isRotating: false
                }
                : {})
        });
    }
    _getCurrentTargetViewport() {
        const viewport = this.makeViewport(this.controllerState.getViewportProps());
        return viewport instanceof WebMercatorViewport && viewport.supportsTargetNavigation
            ? viewport
            : null;
    }
    _areTargetViewportDimensionsEqual(props) {
        return (props.id === this.props.id &&
            props.x === this.props.x &&
            props.y === this.props.y &&
            props.width === this.props.width &&
            props.height === this.props.height);
    }
    _cancelTargetTransition() {
        const transition = this.transitionManager.transition;
        const interpolator = transition.settings.interpolator;
        if (transition.inProgress && interpolator instanceof TargetNavigationInterpolator) {
            transition.cancel();
        }
    }
    /** Replaces a controller-generated map transition with target-aware frame construction. */
    _getTargetTransitionProps(endControllerState, transitionProps) {
        if (!this.targetNavigation ||
            !this._activeTarget ||
            !transitionProps ||
            !transitionProps.transitionDuration) {
            return transitionProps;
        }
        const startViewport = this._getCurrentTargetViewport();
        const targetInfo = startViewport?.getTargetInfo(this._activeTarget.coordinate);
        const endScreenPosition = endControllerState.getState().targetNavigationScreenPosition;
        if (!startViewport || !targetInfo?.isValid || !endScreenPosition) {
            return transitionProps;
        }
        const target = {
            coordinate: [...targetInfo.target],
            screenPosition: [targetInfo.projectedPosition[0], targetInfo.projectedPosition[1]]
        };
        const mode = endControllerState.getState().targetNavigationOperation === 'pan' ? 'pan' : 'orbit';
        const targetSessionGeneration = this._targetSessionGeneration;
        return {
            ...transitionProps,
            transitionInterpolator: mode === 'pan'
                ? new TargetNavigationInterpolator({
                    mode,
                    target,
                    endScreenPosition: [...endScreenPosition],
                    resolveFrame: (props, context) => this._resolveTargetTransitionFrame(props, context)
                })
                : new TargetNavigationInterpolator({
                    mode,
                    target,
                    startRadius: targetInfo.targetDistance,
                    endScreenPosition: [...endScreenPosition],
                    resolveFrame: (props, context) => this._resolveTargetTransitionFrame(props, context)
                }),
            onTransitionInterrupt: this._wrapTargetTransitionEnd(targetSessionGeneration, transitionProps.onTransitionInterrupt),
            onTransitionEnd: this._wrapTargetTransitionEnd(targetSessionGeneration, transitionProps.onTransitionEnd)
        };
    }
    _resolveTargetTransitionFrame(props, context) {
        const current = this.controllerState;
        if (!current.getState().interactionTarget) {
            return null;
        }
        const previous = current._getUpdatedState(context.previousProps, { mode: 'preserve' });
        if (context.mode === 'pan') {
            const candidate = previous._getTargetPanUpdatedState(context.screenPosition, { mode: 'hard' });
            return candidate === previous ? null : candidate.getViewportProps();
        }
        const candidate = previous._getTargetPoseUpdatedState({
            bearing: props.bearing,
            pitch: props.pitch,
            zoom: props.zoom
        }, { mode: 'hard' }, context.radius, context.screenPosition);
        return candidate === previous ? null : candidate.getViewportProps();
    }
    _wrapTargetTransitionEnd(targetSessionGeneration, callback) {
        return transition => {
            // A smooth wheel update interrupts the preceding transition immediately before starting
            // the replacement. The wheel-burst owner bridges that internal restart.
            if (targetSessionGeneration === this._targetSessionGeneration &&
                !this._activeTargetOwners.has('wheel')) {
                this._releaseTargetOwner('transition');
            }
            callback?.(transition);
        };
    }
}
//# sourceMappingURL=map-controller.js.map