// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
/* eslint-disable max-statements, complexity */
import TransitionManager from "./transition-manager.js";
import LinearInterpolator from "../transitions/linear-interpolator.js";
import { deepEqual } from "../utils/deep-equal.js";
import { worldToPixels } from '@math.gl/web-mercator';
import TargetNavigationInterpolator from "../transitions/target-navigation-interpolator.js";
import { copyInteractionTarget, freezeInteractionTarget, getInteractionTargetStructure } from "./interaction-target.js";
const NO_TRANSITION_PROPS = {
    transitionDuration: 0
};
const TARGET_WHEEL_RELEASE_MS = 150;
const DEFAULT_INERTIA = 300;
const REBOUND_DURATION = 300;
const INERTIA_EASING = (t) => 1 - (1 - t) * (1 - t);
const EASE_OUT_EXPONENTIAL = (t) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t));
const EVENT_TYPES = {
    WHEEL: ['wheel'],
    PAN: ['panstart', 'panmove', 'panend'],
    PINCH: ['pinchstart', 'pinchmove', 'pinchend'],
    MULTI_PAN: ['multipanstart', 'multipanmove', 'multipanend'],
    DOUBLE_CLICK: ['dblclick'],
    DOUBLE_CLICK_DRAG: [
        'dblclickdragstart',
        'dblclickdragmove',
        'dblclickdragend',
        'dblclickdragcancel'
    ],
    KEYBOARD: ['keydown']
};
export default class Controller {
    constructor(opts) {
        this.targetNavigation = false;
        this._activeTarget = null;
        this._activeTargetOwners = new Set();
        this._wheelTargetTimer = null;
        this._targetSessionGeneration = 0;
        this._configurationRevision = 0;
        this._targetConstraintDepth = 0;
        this._activeTargetViewStructure = null;
        this._activeTargetViewportType = null;
        this.state = {};
        this._events = {};
        this._isFinalizing = false;
        this._interactionState = {
            isDragging: false
        };
        this._customEvents = [];
        this._eventStartBlocked = null;
        this._panMove = false;
        this._multiPanMode = null;
        this._multiPanStartCenter = null;
        this._lastMultiPanEvent = null;
        this._multiPanDeltaOrigin = [0, 0];
        this._pinchScaleOrigin = 1;
        this._targetOverlap = false;
        this._doubleClickDragAnchor = null;
        /** Input samples shared by pinch handlers and specialized map-controller implementations. */
        this._startPinchRotation = null;
        this._lastPinchEvent = null;
        this._suppressDoubleClickUntil = 0;
        this.invertPan = false;
        this.dragMode = 'rotate';
        this.inertia = 0;
        this.scrollZoom = true;
        this.dragPan = true;
        this.dragRotate = true;
        this.doubleClickZoom = true;
        this.doubleClickDragZoom = true;
        this.touchZoom = true;
        this.touchRotate = false;
        this.multiTouchDrag = null;
        this.trackpadGesture = false;
        this.zoomAround = 'pointer';
        this.keyboard = true;
        this.transitionManager = new TransitionManager({
            ...opts,
            getControllerState: (props, constraintContext) => new this.ControllerState({
                ...props,
                constraintContext,
                makeViewport: opts.makeViewport
            }),
            onViewStateChange: this._onTransition.bind(this),
            onStateChange: this._setInteractionState.bind(this)
        });
        this.handleEvent = this.handleEvent.bind(this);
        this.eventManager = opts.eventManager;
        this.onViewStateChange = opts.onViewStateChange || (() => { });
        this.onStateChange = opts.onStateChange || (() => { });
        this.makeViewport = opts.makeViewport;
        this.pickPosition = opts.pickPosition;
    }
    set events(customEvents) {
        this.toggleEvents(this._customEvents, false);
        this.toggleEvents(customEvents, true);
        this._customEvents = customEvents;
        // Make sure default events are not overwritten
        if (this.props) {
            this.setProps(this.props);
        }
    }
    finalize() {
        this._isFinalizing = true;
        this._releaseAllTargets(true);
        if (this._eventStartBlocked !== null) {
            clearTimeout(this._eventStartBlocked);
            this._eventStartBlocked = null;
        }
        for (const eventName in this._events) {
            if (this._events[eventName]) {
                // @ts-ignore (2345) event type string cannot be assifned to enum
                // eslint-disable-next-line @typescript-eslint/unbound-method
                this.eventManager?.off(eventName, this.handleEvent);
            }
        }
        this.transitionManager.finalize();
    }
    /**
     * Callback for events
     */
    handleEvent(event) {
        try {
            return this._handleEvent(event);
        }
        catch (error) {
            this._releaseAllTargets(true);
            throw error;
        }
    }
    _handleEvent(event) {
        // Force recalculate controller state
        this._controllerState = undefined;
        const eventStartBlocked = this._eventStartBlocked;
        switch (event.type) {
            case 'panstart':
                return eventStartBlocked ? false : this._onPanStart(event);
            case 'panmove':
                return this._onPan(event);
            case 'panend':
                return this._onPanEnd(event);
            case 'pinchstart':
                return eventStartBlocked || !this._isTrackpadGestureAllowed(event)
                    ? false
                    : this._onPinchStart(event);
            case 'pinchmove':
                return this._isTrackpadGestureAllowed(event) ? this._onPinch(event) : false;
            case 'pinchend':
                return this._isTrackpadGestureAllowed(event) ? this._onPinchEnd(event) : false;
            case 'multipanstart':
                return eventStartBlocked ? false : this._onMultiPanStart(event);
            case 'multipanmove':
                return this._onMultiPan(event);
            case 'multipanend':
                return this._onMultiPanEnd(event);
            case 'dblclick':
                return this._onDoubleClick(event);
            case 'dblclickdragstart':
                return eventStartBlocked ? false : this._onDoubleClickDragStart(event);
            case 'dblclickdragmove':
                return this._onDoubleClickDrag(event);
            case 'dblclickdragend':
            case 'dblclickdragcancel':
                return this._onDoubleClickDragEnd(event);
            case 'wheel':
                return this._onWheel(event);
            case 'keydown':
                return this._onKeyDown(event);
            default:
                return false;
        }
    }
    /* Event utils */
    // Event object: http://hammerjs.github.io/api/#event-object
    get controllerState() {
        this._controllerState =
            this._controllerState ||
                new this.ControllerState({
                    makeViewport: this.makeViewport,
                    ...this.props,
                    ...this.state
                });
        return this._controllerState;
    }
    getCenter(event) {
        const { x, y } = this.props;
        const { offsetCenter } = event;
        return [offsetCenter.x - x, offsetCenter.y - y];
    }
    /** Resolves the zoom anchor for pointer-based controls. */
    getZoomPosition(position) {
        if (this.zoomAround === 'pointer') {
            return position;
        }
        const viewport = this.makeViewport(this.controllerState.getViewportProps());
        const [centerX, centerY] = worldToPixels(viewport.center, viewport.pixelProjectionMatrix);
        return [centerX, centerY];
    }
    isPointInBounds(pos, event) {
        const { width, height } = this.props;
        if (event && event.handled) {
            return false;
        }
        const inside = pos[0] >= 0 && pos[0] <= width && pos[1] >= 0 && pos[1] <= height;
        if (inside && event) {
            event.stopPropagation();
        }
        return inside;
    }
    isFunctionKeyPressed(event) {
        const { srcEvent } = event;
        return Boolean(srcEvent.metaKey || srcEvent.altKey || srcEvent.ctrlKey || srcEvent.shiftKey);
    }
    isDragging() {
        return this._interactionState.isDragging || false;
    }
    // When a multi-touch event ends, e.g. pinch, not all pointers are lifted at the same time.
    // This triggers a brief `pan` event.
    // Calling this method will temporarily disable *start events to avoid conflicting transitions.
    blockEvents(timeout) {
        /* global setTimeout */
        if (this._eventStartBlocked !== null) {
            clearTimeout(this._eventStartBlocked);
        }
        const timer = setTimeout(() => {
            if (this._eventStartBlocked === timer) {
                this._eventStartBlocked = null;
            }
        }, timeout);
        this._eventStartBlocked = timer;
    }
    /**
     * Extract interactivity options
     */
    setProps(props) {
        if (this._targetConstraintDepth > 0) {
            throw new Error(this.constructor.name +
                '.setProps cannot be called synchronously from constrainInteractionTargetViewState');
        }
        this._configurationRevision++;
        const targetOptions = props;
        this.targetNavigation = targetOptions._targetNavigation ?? false;
        this.getInteractionTarget = targetOptions.getInteractionTarget;
        this.zoomAround = props.zoomAround ?? 'pointer';
        if (this._activeTarget &&
            (!this.targetNavigation ||
                !this._areTargetViewportDimensionsEqual(props) ||
                !deepEqual(this._activeTargetViewStructure, getInteractionTargetStructure(props), -1) ||
                this.makeViewport(props).constructor !== this._activeTargetViewportType)) {
            this._releaseAllTargets(true);
        }
        if (props.maxBoundsPadding === undefined) {
            props.maxBoundsPadding = null;
        }
        if (props.dragMode) {
            this.dragMode = props.dragMode;
        }
        const oldProps = this.props;
        this.props = props;
        // Controlled view-state feedback may call setProps synchronously from onViewStateChange.
        // Do not keep exposing a controller state built from the preceding props.
        this._controllerState = undefined;
        if (!('transitionInterpolator' in props)) {
            // Add default transition interpolator
            props.transitionInterpolator = this._getTransitionProps().transitionInterpolator;
        }
        this.transitionManager.processViewStateChange(props);
        const { inertia } = props;
        this.inertia = Number.isFinite(inertia)
            ? inertia
            : inertia === true
                ? DEFAULT_INERTIA
                : 0;
        // TODO - make sure these are not reset on every setProps
        const { scrollZoom = true, dragPan = true, dragRotate = true, doubleClickZoom = true, doubleClickDragZoom = false, touchZoom = true, touchRotate = false, multiTouchDrag = touchRotate ? 'rotate' : null, trackpadGesture = false, keyboard = true } = props;
        // Register/unregister events
        const isInteractive = Boolean(this.onViewStateChange);
        this.toggleEvents(EVENT_TYPES.WHEEL, isInteractive && scrollZoom);
        // We always need the pan events to set the correct isDragging state, even if dragPan & dragRotate are both false
        this.toggleEvents(EVENT_TYPES.PAN, isInteractive);
        this.toggleEvents(EVENT_TYPES.PINCH, isInteractive && (touchZoom || multiTouchDrag === 'rotate'));
        this.toggleEvents(EVENT_TYPES.MULTI_PAN, isInteractive && Boolean(multiTouchDrag));
        this.toggleEvents(EVENT_TYPES.DOUBLE_CLICK, isInteractive && doubleClickZoom);
        this.toggleEvents(EVENT_TYPES.DOUBLE_CLICK_DRAG, isInteractive && doubleClickDragZoom);
        this.toggleEvents(EVENT_TYPES.KEYBOARD, isInteractive && keyboard);
        // Interaction toggles
        this.scrollZoom = scrollZoom;
        this.dragPan = dragPan;
        this.dragRotate = dragRotate;
        this.doubleClickZoom = doubleClickZoom;
        this.doubleClickDragZoom = doubleClickDragZoom;
        this.touchZoom = touchZoom;
        this.touchRotate = multiTouchDrag === 'rotate';
        this.multiTouchDrag = multiTouchDrag;
        this.trackpadGesture = trackpadGesture;
        this.keyboard = keyboard;
        // Normalize view state if maxBounds is defined
        const constraintChanged = !oldProps ||
            oldProps.height !== props.height ||
            oldProps.width !== props.width ||
            oldProps.maxBounds !== props.maxBounds ||
            oldProps.maxBoundsPadding !== props.maxBoundsPadding;
        if (constraintChanged && props.maxBounds) {
            // Constraint inputs changed, try re-normalize the props
            const controllerState = new this.ControllerState({ ...props, makeViewport: this.makeViewport });
            const normalizedProps = controllerState.getViewportProps();
            const changed = Object.keys(normalizedProps).some(key => !deepEqual(normalizedProps[key], props[key], 1));
            if (changed) {
                // some props are updated after normalization
                this.updateViewport(controllerState);
            }
        }
    }
    updateTransition() {
        try {
            this.transitionManager.updateTransition();
        }
        catch (error) {
            this._releaseAllTargets(true);
            throw error;
        }
    }
    toggleEvents(eventNames, enabled) {
        if (this.eventManager) {
            eventNames.forEach(eventName => {
                if (this._events[eventName] !== enabled) {
                    this._events[eventName] = enabled;
                    if (enabled) {
                        // eslint-disable-next-line @typescript-eslint/unbound-method
                        this.eventManager.on(eventName, this.handleEvent);
                    }
                    else {
                        // eslint-disable-next-line @typescript-eslint/unbound-method
                        this.eventManager.off(eventName, this.handleEvent);
                    }
                }
            });
        }
    }
    // Private Methods
    /* Callback util */
    // formats map state and invokes callback function
    updateViewport(newControllerState, extraProps = null, interactionState = {}) {
        const state = newControllerState.getState();
        const sessionId = state.targetNavigationSessionId;
        if (sessionId !== undefined &&
            sessionId !== null &&
            (sessionId !== this._targetSessionGeneration || !this._activeTarget))
            return;
        if (this._activeTarget && !state.interactionTarget)
            this._releaseAllTargets(true);
        extraProps = this._getTargetTransitionProps(newControllerState, extraProps);
        if (state.interactionTarget) {
            const isTargetRotation = (this._activeTargetOwners.has('rotate') && interactionState.isDragging !== false) ||
                (state.targetNavigationOperation === 'rotate' && interactionState.isRotating === true);
            interactionState = {
                ...interactionState,
                interactionTargetPosition: [...state.interactionTarget.coordinate],
                rotationPivotPosition: isTargetRotation
                    ? [...state.interactionTarget.coordinate]
                    : undefined
            };
        }
        const viewState = { ...newControllerState.getViewportProps(), ...extraProps };
        // TODO - to restore diffing, we need to include interactionState
        const oldControllerState = this.controllerState;
        const changed = oldControllerState !== newControllerState;
        const oldViewState = oldControllerState?.getViewportProps();
        // const oldViewState = this.controllerState.getViewportProps();
        // const changed = Object.keys(viewState).some(key => oldViewState[key] !== viewState[key]);
        this.state = newControllerState.getState();
        // Expose the state just emitted by this synchronous event. A controlled setProps callback
        // will invalidate this cache again and replace it with the accepted external state.
        this._controllerState = newControllerState;
        this._setInteractionState(interactionState);
        if (changed) {
            if (this.onViewStateChange) {
                this.onViewStateChange({
                    viewState,
                    interactionState: this._interactionState,
                    oldViewState,
                    viewId: this.props.id
                });
            }
        }
    }
    _onTransition(params) {
        this._interactionState.viewId = this.props.id;
        this.onViewStateChange({
            ...params,
            interactionState: this._interactionState,
            viewId: this.props.id
        });
    }
    _setInteractionState(newStates) {
        Object.assign(this._interactionState, newStates, { viewId: this.props.id });
        this.onStateChange(this._interactionState);
    }
    /** Maps a semantic input lifecycle to the constraint policy seen by controller state. */
    _getConstraintContext(_action, phase) {
        if (!this.props.rubberBand) {
            return { mode: 'hard' };
        }
        return { mode: phase === 'update' ? 'elastic' : phase === 'end' ? 'rebound' : 'hard' };
    }
    /** Returns a rebound transition when hard resolution changed the displayed viewport props. */
    _getReboundTransition(constraintContext, nextControllerState) {
        if (constraintContext.mode !== 'rebound') {
            return null;
        }
        const nextViewportProps = nextControllerState.getViewportProps();
        // At interaction end controllerState is reconstructed without the preceding elastic context.
        // Compare the hard-resolved destination with the displayed props to detect visible overshoot.
        const shouldRebound = Object.keys(nextViewportProps).some(key => !deepEqual(this.props[key], nextViewportProps[key], 1));
        return shouldRebound
            ? {
                ...this._getTransitionProps(),
                transitionDuration: REBOUND_DURATION,
                transitionEasing: EASE_OUT_EXPONENTIAL
            }
            : null;
    }
    /* Event handlers */
    // Default handler for the `panstart` event.
    _onPanStart(event) {
        const pos = this.getCenter(event);
        if (!this.isPointInBounds(pos, event)) {
            return false;
        }
        let alternateMode = this.isFunctionKeyPressed(event) || event.rightButton || false;
        if (this.invertPan || this.dragMode === 'pan') {
            // invertPan is replaced by props.dragMode, keeping for backward compatibility
            alternateMode = !alternateMode;
        }
        const action = alternateMode ? 'pan' : 'rotate';
        const acquisitionPosition = this._getGestureAcquisitionPosition(event);
        if (this._isTargetPositionInBounds(acquisitionPosition) &&
            (event.pointerType !== 'trackpad' || this.trackpadGesture) &&
            (action === 'pan' ? this.dragPan : this.dragRotate)) {
            this._acquireTarget(action, event.pointerType === 'trackpad'
                ? 'trackpad'
                : event.pointerType === 'touch'
                    ? 'touch'
                    : 'pointer', acquisitionPosition);
        }
        const constraintContext = this._getConstraintContext(action, 'start');
        const newControllerState = alternateMode
            ? this.controllerState.panStart({ pos }, constraintContext)
            : this.controllerState.rotateStart({ pos }, constraintContext);
        this._panMove = alternateMode;
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, { isDragging: true });
        return true;
    }
    // Default handler for the `panmove` and `panend` event.
    _onPan(event) {
        if (!this.isDragging()) {
            return false;
        }
        return this._panMove ? this._onPanMove(event) : this._onPanRotate(event);
    }
    _onPanEnd(event) {
        if (!this.isDragging()) {
            return false;
        }
        const handled = this._panMove ? this._onPanMoveEnd(event) : this._onPanRotateEnd(event);
        if (handled)
            this._endTargetGesture(this._panMove ? 'pan' : 'rotate');
        return handled;
    }
    // Default handler for panning to move.
    // Called by `_onPan` when panning without function key pressed.
    _onPanMove(event) {
        if (!this.dragPan) {
            return false;
        }
        const pos = this.getCenter(event);
        const newControllerState = this.controllerState.pan({ pos }, this._getConstraintContext('pan', 'update'));
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, {
            isDragging: true,
            isPanning: true
        });
        return true;
    }
    _onPanMoveEnd(event) {
        const { inertia } = this;
        if (this.dragPan && inertia && event.velocity) {
            const pos = this.getCenter(event);
            const endPos = [
                pos[0] + (event.velocityX * inertia) / 2,
                pos[1] + (event.velocityY * inertia) / 2
            ];
            const newControllerState = this.controllerState.pan({ pos: endPos }).panEnd();
            this.updateViewport(newControllerState, {
                ...this._getTransitionProps(),
                transitionDuration: inertia,
                transitionEasing: INERTIA_EASING
            }, {
                isDragging: false,
                isPanning: true
            });
        }
        else {
            const currentControllerState = this.controllerState;
            const constraintContext = this._getConstraintContext('pan', 'end');
            const newControllerState = currentControllerState.panEnd(constraintContext);
            const reboundTransition = this._getReboundTransition(constraintContext, newControllerState);
            this.updateViewport(newControllerState, reboundTransition, {
                isDragging: false,
                isPanning: Boolean(reboundTransition)
            });
        }
        return true;
    }
    // Default handler for panning to rotate.
    // Called by `_onPan` when panning with function key pressed.
    _onPanRotate(event) {
        if (!this.dragRotate) {
            return false;
        }
        const pos = this.getCenter(event);
        const newControllerState = this.controllerState.rotate({ pos }, this._getConstraintContext('rotate', 'update'));
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, {
            isDragging: true,
            isRotating: true
        });
        return true;
    }
    _onPanRotateEnd(event) {
        const { inertia } = this;
        if (this.dragRotate && inertia && event.velocity) {
            const pos = this.getCenter(event);
            const endPos = [
                pos[0] + (event.velocityX * inertia) / 2,
                pos[1] + (event.velocityY * inertia) / 2
            ];
            const newControllerState = this.controllerState.rotate({ pos: endPos }).rotateEnd();
            this.updateViewport(newControllerState, {
                ...this._getTransitionProps(),
                transitionDuration: inertia,
                transitionEasing: INERTIA_EASING
            }, {
                isDragging: false,
                isRotating: true
            });
        }
        else {
            const currentControllerState = this.controllerState;
            const constraintContext = this._getConstraintContext('rotate', 'end');
            const newControllerState = currentControllerState.rotateEnd(constraintContext);
            const reboundTransition = this._getReboundTransition(constraintContext, newControllerState);
            this.updateViewport(newControllerState, reboundTransition, {
                isDragging: false,
                isRotating: Boolean(reboundTransition)
            });
        }
        return true;
    }
    // Default handler for the `wheel` event.
    _onWheel(event) {
        if (!this.scrollZoom) {
            return false;
        }
        if (this.trackpadGesture && event.device !== 'mouse') {
            return false;
        }
        const pos = this.getCenter(event);
        if (!this.isPointInBounds(pos, event)) {
            return false;
        }
        event.srcEvent.preventDefault();
        const zoomPosition = this.getZoomPosition(pos);
        this._acquireWheelTarget(zoomPosition);
        const { speed = 0.01, smooth = false } = this.scrollZoom === true ? {} : this.scrollZoom;
        const { delta } = event;
        // Map wheel delta to relative scale
        let scale = 2 / (1 + Math.exp(-Math.abs(delta * speed)));
        if (delta < 0 && scale !== 0) {
            scale = 1 / scale;
        }
        const transitionProps = smooth
            ? { ...this._getTransitionProps({ around: zoomPosition }), transitionDuration: 250 }
            : NO_TRANSITION_PROPS;
        const newControllerState = this.controllerState.zoom({ pos: zoomPosition, scale });
        this.updateViewport(newControllerState, transitionProps, {
            isZooming: true,
            isPanning: true
        });
        // When there's no transition (duration = 0), immediately reset interaction state
        // since _onTransitionEnd callback won't fire
        if (!smooth) {
            this._setInteractionState({ isZooming: false, isPanning: false });
        }
        return true;
    }
    _onMultiPanStart(event) {
        const { multiTouchDrag } = this;
        if (!multiTouchDrag || !this._isMultiPanEventAllowed(event, multiTouchDrag)) {
            return false;
        }
        const currentCenter = event.offsetCenter;
        if (!this.isPointInBounds(this.getCenter(event), event)) {
            return false;
        }
        const isTrackpad = event.pointerType === 'trackpad';
        const handoffToStock = Boolean(this._lastPinchEvent && (this._activeTarget || this._targetOverlap));
        const startCenter = {
            x: currentCenter.x - (isTrackpad || handoffToStock ? 0 : event.deltaX),
            y: currentCenter.y - (isTrackpad || handoffToStock ? 0 : event.deltaY)
        };
        const startEvent = { ...event, offsetCenter: startCenter };
        const pos = this.getCenter(startEvent);
        if (this._lastPinchEvent && (this._activeTarget || this._targetOverlap)) {
            // Independent translation and pinch recognizers do not describe one atomic camera
            // operation. Hand both to stock navigation from the displayed state, without replay.
            const pinchEvent = this._lastPinchEvent;
            this._releaseAllTargets(true);
            this._targetOverlap = true;
            this._pinchScaleOrigin = pinchEvent.scale;
            this._startPinchRotation = pinchEvent.rotation;
            const pinchPosition = this.getCenter(pinchEvent);
            const rebased = this.controllerState
                .zoomStart({ pos: this.getZoomPosition(pinchPosition) })
                .rotateStart({ pos: pinchPosition });
            this.state = rebased.getState();
            this._controllerState = rebased;
        }
        else if (!this._targetOverlap && this._isTargetPositionInBounds(pos)) {
            this._acquireTarget(multiTouchDrag, isTrackpad ? 'trackpad' : 'touch', pos);
        }
        const newControllerState = multiTouchDrag === 'pan'
            ? this.controllerState.panStart({ pos }, this._getConstraintContext('pan', 'start'))
            : this.controllerState.rotateStart({ pos }, this._getConstraintContext('rotate', 'start'));
        this._multiPanMode = multiTouchDrag;
        this._multiPanStartCenter = startCenter;
        this._multiPanDeltaOrigin = handoffToStock ? [event.deltaX, event.deltaY] : [0, 0];
        this._lastMultiPanEvent = startEvent;
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, { isDragging: true });
        return true;
    }
    _onMultiPan(event) {
        const { mode, event: panEvent } = this._getMultiPanEvent(event);
        if (!mode || !panEvent || !this.isDragging()) {
            return false;
        }
        this._lastMultiPanEvent = panEvent;
        return mode === 'pan' ? this._onPanMove(panEvent) : this._onPanRotate(panEvent);
    }
    _onMultiPanEnd(event) {
        const { mode, event: panEvent } = this._getMultiPanEvent(event);
        if (!mode || !panEvent || !this.isDragging()) {
            this._resetMultiPan();
            return false;
        }
        if (this._targetOverlap && this._lastPinchEvent) {
            this._resetMultiPan();
            return true;
        }
        const handled = mode === 'pan' ? this._onPanMoveEnd(panEvent) : this._onPanRotateEnd(panEvent);
        this._resetMultiPan();
        this._targetOverlap = false;
        if (handled)
            this._endTargetGesture(mode);
        return handled;
    }
    _isTrackpadGestureAllowed(event) {
        return event.pointerType !== 'trackpad' || this.trackpadGesture;
    }
    _isMultiPanEventAllowed(event, mode) {
        if (event.pointerType === 'trackpad') {
            return this.trackpadGesture && (mode === 'pan' ? this.dragPan : this.dragRotate);
        }
        return event.pointerType === 'touch' && (mode === 'pan' ? this.dragPan : this.dragRotate);
    }
    _getMultiPanEvent(event) {
        const mode = this._multiPanMode;
        const startCenter = this._multiPanStartCenter;
        if (!mode || !startCenter) {
            return { mode: null, event: null };
        }
        return {
            mode,
            event: {
                ...event,
                offsetCenter: {
                    x: startCenter.x + event.deltaX - this._multiPanDeltaOrigin[0],
                    y: startCenter.y + event.deltaY - this._multiPanDeltaOrigin[1]
                }
            }
        };
    }
    _resetMultiPan() {
        this._multiPanMode = null;
        this._multiPanStartCenter = null;
        this._lastMultiPanEvent = null;
        this._multiPanDeltaOrigin = [0, 0];
    }
    // Default handler for the `pinchstart` event.
    _onPinchStart(event) {
        this._doubleClickDragAnchor = null;
        const pos = this.getCenter(event);
        if (!this.isPointInBounds(pos, event)) {
            return false;
        }
        this._pinchScaleOrigin = 1;
        if (this._multiPanMode && this._activeTarget) {
            this._releaseAllTargets(true);
            this._targetOverlap = true;
            const previous = this._lastMultiPanEvent || event;
            this._multiPanStartCenter = { ...previous.offsetCenter };
            this._multiPanDeltaOrigin = [previous.deltaX, previous.deltaY];
            const previousPosition = this.getCenter(previous);
            const rebased = this._multiPanMode === 'pan'
                ? this.controllerState.panStart({ pos: previousPosition })
                : this.controllerState.rotateStart({ pos: previousPosition });
            this.state = rebased.getState();
            this._controllerState = rebased;
        }
        const owners = [
            ...(this.touchZoom ? ['zoom'] : []),
            ...(this.touchRotate ? ['rotate'] : [])
        ];
        if (!this._targetOverlap &&
            owners.length &&
            (!this.touchZoom || !this.touchRotate || this.controllerState.zoomRotate)) {
            this._acquireTarget('pinch', event.pointerType === 'trackpad' ? 'trackpad' : 'touch', this.getZoomPosition(pos), owners);
        }
        const newControllerState = this.controllerState
            .zoomStart({ pos: this.getZoomPosition(pos) }, this._getConstraintContext('zoom', 'start'))
            .rotateStart({ pos }, this._getConstraintContext('rotate', 'start'));
        // hack - hammer's `rotation` field doesn't seem to produce the correct angle
        this._startPinchRotation = event.rotation;
        this._lastPinchEvent = event;
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, { isDragging: true });
        return true;
    }
    // Default handler for the `pinchmove` and `pinchend` events.
    _onPinch(event) {
        if (!this.touchZoom && !this.touchRotate) {
            return false;
        }
        if (!this.isDragging()) {
            return false;
        }
        let newControllerState = this.controllerState;
        if (this._activeTarget && this.touchZoom && this.touchRotate && newControllerState.zoomRotate) {
            newControllerState = newControllerState.zoomRotate({
                scale: event.scale,
                deltaAngleX: (this._startPinchRotation || 0) - event.rotation
            }, this._getConstraintContext('zoom', 'update'));
        }
        else {
            if (this.touchZoom) {
                const scale = event.scale / this._pinchScaleOrigin;
                const pos = this.getCenter(event);
                newControllerState = newControllerState.zoom({ pos: this.getZoomPosition(pos), scale }, this._getConstraintContext('zoom', 'update'));
            }
            if (this.touchRotate) {
                const { rotation } = event;
                newControllerState = newControllerState.rotate({ deltaAngleX: (this._startPinchRotation || 0) - rotation }, this._getConstraintContext('rotate', 'update'));
            }
        }
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, {
            isDragging: true,
            isPanning: this.touchZoom,
            isZooming: this.touchZoom,
            isRotating: this.touchRotate
        });
        this._lastPinchEvent = event;
        return true;
    }
    _onPinchEnd(event) {
        if (!this.isDragging()) {
            return false;
        }
        if (this._targetOverlap && this._multiPanMode) {
            const previous = this._lastMultiPanEvent || event;
            const position = this.getCenter(previous);
            let rebased = this.controllerState.zoomEnd().rotateEnd();
            rebased =
                this._multiPanMode === 'pan'
                    ? rebased.panStart({ pos: position })
                    : rebased.rotateStart({ pos: position });
            this._multiPanStartCenter = { ...previous.offsetCenter };
            this._multiPanDeltaOrigin = [previous.deltaX, previous.deltaY];
            this._startPinchRotation = null;
            this._lastPinchEvent = null;
            this._pinchScaleOrigin = 1;
            this.updateViewport(rebased, NO_TRANSITION_PROPS, { isDragging: true, isZooming: false });
            return true;
        }
        const { inertia } = this;
        const { _lastPinchEvent } = this;
        if (this.touchZoom && inertia && _lastPinchEvent && event.scale !== _lastPinchEvent.scale) {
            const pos = this.getCenter(event);
            const zoomPosition = this.getZoomPosition(pos);
            let newControllerState = this.controllerState.rotateEnd();
            const z = Math.log2(event.scale / this._pinchScaleOrigin);
            const velocityZ = (z - Math.log2(_lastPinchEvent.scale / this._pinchScaleOrigin)) /
                (event.deltaTime - _lastPinchEvent.deltaTime);
            const endScale = Math.pow(2, z + (velocityZ * inertia) / 2);
            newControllerState = newControllerState.zoom({ pos: zoomPosition, scale: endScale }).zoomEnd();
            this.updateViewport(newControllerState, {
                ...this._getTransitionProps({ around: zoomPosition }),
                transitionDuration: inertia,
                transitionEasing: INERTIA_EASING
            }, {
                isDragging: false,
                isPanning: this.touchZoom,
                isZooming: this.touchZoom,
                isRotating: false
            });
            this.blockEvents(inertia);
        }
        else {
            const currentControllerState = this.controllerState;
            const zoomConstraintContext = this._getConstraintContext('zoom', 'end');
            const rotateConstraintContext = this._getConstraintContext('rotate', 'end');
            const newControllerState = currentControllerState
                .zoomEnd(zoomConstraintContext)
                .rotateEnd(rotateConstraintContext);
            const reboundTransition = this._getReboundTransition(this.touchZoom ? zoomConstraintContext : rotateConstraintContext, newControllerState);
            this.updateViewport(newControllerState, reboundTransition, {
                isDragging: false,
                isPanning: Boolean(reboundTransition) && this.touchZoom,
                isZooming: Boolean(reboundTransition) && this.touchZoom,
                isRotating: Boolean(reboundTransition) && this.touchRotate
            });
        }
        this._startPinchRotation = null;
        this._lastPinchEvent = null;
        this._pinchScaleOrigin = 1;
        this._targetOverlap = false;
        this._endTargetGesture('zoom');
        this._endTargetGesture('rotate');
        return true;
    }
    // Default handler for the `dblclick` event.
    _onDoubleClick(event) {
        if (!this.doubleClickZoom) {
            return false;
        }
        if (Date.now() < this._suppressDoubleClickUntil) {
            return false;
        }
        const pos = this.getCenter(event);
        if (!this.isPointInBounds(pos, event)) {
            return false;
        }
        const isZoomOut = this.isFunctionKeyPressed(event);
        const zoomPosition = this.getZoomPosition(pos);
        this._acquireTarget('zoom', 'doubleClick', zoomPosition, ['transition']);
        const newControllerState = this.controllerState.zoom({
            pos: zoomPosition,
            scale: isZoomOut ? 0.5 : 2
        });
        this.updateViewport(newControllerState, this._getTransitionProps({ around: zoomPosition }), {
            isZooming: true,
            isPanning: true
        });
        if (!this.transitionManager.transition.inProgress)
            this._releaseTargetOwner('transition');
        this.blockEvents(100);
        return true;
    }
    _onDoubleClickDragStart(event) {
        if (!this.doubleClickDragZoom) {
            this._doubleClickDragAnchor = null;
            return false;
        }
        const pos = this.getCenter(event);
        if (!this.isPointInBounds(pos, event)) {
            this._doubleClickDragAnchor = null;
            return false;
        }
        this._doubleClickDragAnchor = this.getZoomPosition(pos);
        this._acquireTarget('zoom', 'doubleClick', this._doubleClickDragAnchor);
        let newControllerState = this.controllerState.zoomStart({ pos: this._doubleClickDragAnchor }, this._getConstraintContext('zoom', 'start'));
        if (event.scale !== 1) {
            newControllerState = newControllerState.zoom({ pos: this._doubleClickDragAnchor, scale: event.scale }, this._getConstraintContext('zoom', 'update'));
        }
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, {
            isDragging: true,
            isPanning: true,
            isZooming: true
        });
        return true;
    }
    _onDoubleClickDrag(event) {
        const pos = this._doubleClickDragAnchor;
        if (!pos) {
            return false;
        }
        const newControllerState = this.controllerState.zoom({ pos, scale: event.scale }, this._getConstraintContext('zoom', 'update'));
        this.updateViewport(newControllerState, NO_TRANSITION_PROPS, {
            isDragging: true,
            isPanning: true,
            isZooming: true
        });
        return true;
    }
    _onDoubleClickDragEnd(_event) {
        const pos = this._doubleClickDragAnchor;
        if (!pos) {
            return false;
        }
        this._doubleClickDragAnchor = null;
        const currentControllerState = this.controllerState;
        const constraintContext = this._getConstraintContext('zoom', 'end');
        const newControllerState = currentControllerState.zoomEnd(constraintContext);
        const reboundTransition = this._getReboundTransition(constraintContext, newControllerState);
        this.updateViewport(newControllerState, reboundTransition, {
            isDragging: false,
            isPanning: Boolean(reboundTransition),
            isZooming: Boolean(reboundTransition)
        });
        this._endTargetGesture('zoom');
        this._suppressDoubleClickUntil = Date.now() + 100;
        this.blockEvents(100);
        return true;
    }
    // Default handler for the `keydown` event
    _onKeyDown(event) {
        if (!this.keyboard) {
            return false;
        }
        const funcKey = this.isFunctionKeyPressed(event);
        // @ts-ignore
        const { zoomSpeed, moveSpeed, rotateSpeedX, rotateSpeedY } = this.keyboard === true ? {} : this.keyboard;
        const code = event.srcEvent.code;
        if (['Minus', 'Equal', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(code)) {
            const operation = code === 'Minus' || code === 'Equal' ? 'zoom' : funcKey ? 'rotate' : 'pan';
            this._acquireTarget(operation, 'keyboard', null, ['transition']);
        }
        const { controllerState } = this;
        let newControllerState;
        const interactionState = {};
        switch (event.srcEvent.code) {
            case 'Minus':
                newControllerState =
                    this._activeTarget && controllerState.zoomByKeyboard
                        ? controllerState.zoomByKeyboard({
                            direction: 'out',
                            speed: zoomSpeed,
                            repeat: funcKey ? 2 : 1
                        })
                        : funcKey
                            ? controllerState.zoomOut(zoomSpeed).zoomOut(zoomSpeed)
                            : controllerState.zoomOut(zoomSpeed);
                interactionState.isZooming = true;
                break;
            case 'Equal':
                newControllerState =
                    this._activeTarget && controllerState.zoomByKeyboard
                        ? controllerState.zoomByKeyboard({
                            direction: 'in',
                            speed: zoomSpeed,
                            repeat: funcKey ? 2 : 1
                        })
                        : funcKey
                            ? controllerState.zoomIn(zoomSpeed).zoomIn(zoomSpeed)
                            : controllerState.zoomIn(zoomSpeed);
                interactionState.isZooming = true;
                break;
            case 'ArrowLeft':
                if (funcKey) {
                    newControllerState = controllerState.rotateLeft(rotateSpeedX);
                    interactionState.isRotating = true;
                }
                else {
                    newControllerState = controllerState.moveLeft(moveSpeed);
                    interactionState.isPanning = true;
                }
                break;
            case 'ArrowRight':
                if (funcKey) {
                    newControllerState = controllerState.rotateRight(rotateSpeedX);
                    interactionState.isRotating = true;
                }
                else {
                    newControllerState = controllerState.moveRight(moveSpeed);
                    interactionState.isPanning = true;
                }
                break;
            case 'ArrowUp':
                if (funcKey) {
                    newControllerState = controllerState.rotateUp(rotateSpeedY);
                    interactionState.isRotating = true;
                }
                else {
                    newControllerState = controllerState.moveUp(moveSpeed);
                    interactionState.isPanning = true;
                }
                break;
            case 'ArrowDown':
                if (funcKey) {
                    newControllerState = controllerState.rotateDown(rotateSpeedY);
                    interactionState.isRotating = true;
                }
                else {
                    newControllerState = controllerState.moveDown(moveSpeed);
                    interactionState.isPanning = true;
                }
                break;
            default:
                return false;
        }
        this.updateViewport(newControllerState, this._getTransitionProps(), interactionState);
        if (!this.transitionManager.transition.inProgress)
            this._releaseTargetOwner('transition');
        return true;
    }
    _getTransitionProps(opts) {
        const { transition } = this;
        if (!transition || !transition.transitionInterpolator) {
            return NO_TRANSITION_PROPS;
        }
        // Enables Transitions on double-click/tap and key-down events.
        return opts
            ? {
                ...transition,
                transitionInterpolator: new LinearInterpolator({
                    ...opts,
                    ...transition.transitionInterpolator.opts,
                    makeViewport: this.controllerState.makeViewport
                })
            }
            : transition;
    }
    /** Resolves one fresh numeric target. A configured provider is authoritative. */
    resolveInteractionTarget(screenPosition, operation, source) {
        // Elastic MapState constraints require a separate target-aware rebound definition. Until that
        // contract is implemented, preserve the complete stock rubber-band lifecycle.
        if (!this.targetNavigation) {
            return null;
        }
        const viewport = this.controllerState.getTargetNavigationViewport?.(operation);
        if (!viewport) {
            return null;
        }
        const configurationRevision = this._configurationRevision;
        const provider = this.getInteractionTarget;
        let resolved = null;
        if (provider) {
            resolved = provider({
                viewId: this.props.id,
                operation,
                source,
                screenPosition: screenPosition && [...screenPosition],
                viewport
            });
        }
        else if (screenPosition && this.pickPosition) {
            const picked = this.pickPosition(this.props.x + screenPosition[0], this.props.y + screenPosition[1]);
            if (picked?.coordinate &&
                picked.coordinate.length >= 3 &&
                (!picked.viewport ||
                    (picked.viewport.id === viewport.id &&
                        picked.viewport.constructor === viewport.constructor))) {
                resolved = {
                    coordinate: picked.coordinate.slice(0, 3),
                    screenPosition: [...screenPosition]
                };
            }
        }
        if (configurationRevision !== this._configurationRevision ||
            !this.targetNavigation ||
            provider !== this.getInteractionTarget) {
            return null;
        }
        return resolved;
    }
    /** Whether target navigation currently owns an acquired numeric coordinate. */
    hasActiveInteractionTarget() {
        return Boolean(this._activeTarget);
    }
    /** Builds camera-specific state while the base controller owns session lifetime. */
    createInteractionTargetState(target, session) {
        return this.controllerState.withInteractionTarget(target, session);
    }
    /** Guards application constraints against synchronous controller reconfiguration. */
    runInteractionTargetConstraint(callback) {
        this._targetConstraintDepth++;
        try {
            return callback();
        }
        finally {
            this._targetConstraintDepth--;
        }
    }
    _endTargetGesture(owner) {
        if (this._activeTarget && this.transitionManager.transition.inProgress)
            this._activeTargetOwners.add('transition');
        this._releaseTargetOwner(owner);
    }
    _isTargetPositionInBounds(pos) {
        return pos[0] >= 0 && pos[0] <= this.props.width && pos[1] >= 0 && pos[1] <= this.props.height;
    }
    /** Returns the pointer/touch origin, or the first recognized trackpad sample. */
    _getGestureAcquisitionPosition(event) {
        if (event.pointerType === 'trackpad') {
            return this.getCenter(event);
        }
        const deltaX = Number.isFinite(event.deltaX) ? event.deltaX : 0;
        const deltaY = Number.isFinite(event.deltaY) ? event.deltaY : 0;
        return this.getCenter({
            ...event,
            offsetCenter: {
                x: event.offsetCenter.x - deltaX,
                y: event.offsetCenter.y - deltaY
            }
        });
    }
    _acquireTarget(operation, source, screenPosition, owners = [
        operation === 'pinch' ? 'zoom' : operation
    ]) {
        if (!this.targetNavigation ||
            !this.controllerState.getTargetNavigationViewport?.(operation) ||
            !this.controllerState.validateInteractionTarget ||
            !this.controllerState.withInteractionTarget ||
            !this.controllerState.withoutInteractionTarget)
            return null;
        if (this._activeTarget) {
            const reuseActiveTarget = owners.length === 1 && owners[0] === 'wheel' && this._activeTargetOwners.has('wheel');
            if (reuseActiveTarget) {
                for (const owner of owners)
                    this._activeTargetOwners.add(owner);
                return this._activeTarget;
            }
            // An active transition is a completed input session. A new gesture must acquire a fresh
            // scene target; only an explicitly continued wheel burst may reuse its frozen snapshot.
            this._releaseAllTargets(true);
        }
        try {
            const configurationRevision = this._configurationRevision;
            const resolved = copyInteractionTarget(this.resolveInteractionTarget(screenPosition, operation, source));
            const target = freezeInteractionTarget(resolved && this.controllerState.validateInteractionTarget(resolved));
            if (!target ||
                !this.targetNavigation ||
                configurationRevision !== this._configurationRevision) {
                return null;
            }
            this._activeTarget = target;
            this._targetSessionGeneration++;
            this._activeTargetViewStructure = getInteractionTargetStructure(this.props);
            this._activeTargetViewportType =
                this.controllerState.getTargetNavigationViewport?.()?.constructor;
            for (const owner of owners)
                this._activeTargetOwners.add(owner);
            this._installTargetState(target, operation, source, screenPosition);
            return target;
        }
        catch (error) {
            this._releaseAllTargets(true);
            this._setInteractionState({
                interactionTargetPosition: undefined,
                rotationPivotPosition: undefined
            });
            throw error;
        }
    }
    _acquireWheelTarget(screenPosition) {
        if (!this.targetNavigation || !this.controllerState.getTargetNavigationViewport?.('zoom'))
            return null;
        this._acquireTarget('zoom', 'wheel', screenPosition, ['wheel']);
        if (!this._activeTarget)
            return null;
        this._activeTargetOwners.add('transition');
        if (this._wheelTargetTimer) {
            clearTimeout(this._wheelTargetTimer);
        }
        this._wheelTargetTimer = setTimeout(() => {
            this._wheelTargetTimer = null;
            this._releaseTargetOwner('wheel');
            if (!this.transitionManager.transition.inProgress) {
                this._releaseTargetOwner('transition');
            }
        }, TARGET_WHEEL_RELEASE_MS);
        return this._activeTarget;
    }
    _installTargetState(target, operation, source, inputOrigin) {
        const state = this.createInteractionTargetState(target, {
            viewId: this.props.id,
            operation,
            source,
            sessionId: this._targetSessionGeneration,
            inputOrigin
        });
        this.state = state.getState();
        this._controllerState = state;
        this._setInteractionState({ interactionTargetPosition: [...target.coordinate] });
    }
    _releaseTargetOwner(owner) {
        this._activeTargetOwners.delete(owner);
        if (this._activeTargetOwners.size === 0) {
            this._clearTargetState();
        }
    }
    _releaseAllTargets(cancelTransition = false) {
        if (cancelTransition) {
            this._cancelTargetTransition();
        }
        if (this._wheelTargetTimer) {
            clearTimeout(this._wheelTargetTimer);
            this._wheelTargetTimer = null;
        }
        this._activeTargetOwners.clear();
        this._clearTargetState(cancelTransition);
    }
    _clearTargetState(cancelInteraction = false) {
        if (!this._activeTarget) {
            return;
        }
        this._activeTarget = null;
        this._activeTargetViewStructure = null;
        this._activeTargetViewportType = null;
        this._targetSessionGeneration++;
        if (this._isFinalizing) {
            // ViewManager may already have removed the owning view. Disposal must not call its
            // makeViewport callback or reconstruct a constrained camera that will never be used.
            this.state = {};
            this._controllerState = undefined;
        }
        else {
            const state = this.controllerState.withoutInteractionTarget();
            this.state = state.getState();
            this._controllerState = state;
        }
        this._setInteractionState({
            interactionTargetPosition: undefined,
            rotationPivotPosition: undefined,
            ...(cancelInteraction
                ? {
                    isDragging: false,
                    isPanning: false,
                    isZooming: false,
                    isRotating: false
                }
                : {})
        });
    }
    _areTargetViewportDimensionsEqual(props) {
        return (props.id === this.props.id &&
            props.x === this.props.x &&
            props.y === this.props.y &&
            props.width === this.props.width &&
            props.height === this.props.height);
    }
    _cancelTargetTransition() {
        const transition = this.transitionManager.transition;
        const interpolator = transition.settings.interpolator;
        if (transition.inProgress && interpolator instanceof TargetNavigationInterpolator) {
            transition.cancel();
        }
    }
    /** Attaches model-specific frame reconstruction without replacing the canonical scheduler. */
    _getTargetTransitionProps(endState, transitionProps) {
        if (!this.targetNavigation || !this._activeTarget || !transitionProps?.transitionDuration)
            return transitionProps;
        const interpolator = this.controllerState.createTargetNavigationInterpolator?.(endState, () => this.controllerState);
        if (!interpolator)
            return { ...transitionProps, transitionDuration: 0 };
        const generation = this._targetSessionGeneration;
        return {
            ...transitionProps,
            transitionInterpolator: interpolator,
            onTransitionInterrupt: this._wrapTargetTransitionEnd(generation, transitionProps.onTransitionInterrupt),
            onTransitionEnd: this._wrapTargetTransitionEnd(generation, transitionProps.onTransitionEnd)
        };
    }
    _wrapTargetTransitionEnd(targetSessionGeneration, callback) {
        return transition => {
            // A smooth wheel update interrupts the preceding transition immediately before starting
            // the replacement. The wheel-burst owner bridges that internal restart.
            if (targetSessionGeneration === this._targetSessionGeneration &&
                !this._activeTargetOwners.has('wheel')) {
                this._releaseTargetOwner('transition');
            }
            callback?.(transition);
        };
    }
}
//# sourceMappingURL=controller.js.map