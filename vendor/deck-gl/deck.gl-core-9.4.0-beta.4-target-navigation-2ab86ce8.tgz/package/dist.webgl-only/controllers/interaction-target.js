// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
import isFiniteTuple from "../utils/is-finite-tuple.js";
/** Copies only finite numeric target fields, excluding application objects and metadata. */
export function copyInteractionTarget(target) {
    if (!target ||
        !isFiniteTuple(target.coordinate, 3) ||
        !isFiniteTuple(target.screenPosition, 2) ||
        (target.minimumTargetDistance !== undefined &&
            (!Number.isFinite(target.minimumTargetDistance) || target.minimumTargetDistance < 0))) {
        return null;
    }
    return {
        coordinate: [...target.coordinate],
        screenPosition: [...target.screenPosition],
        ...(target.minimumTargetDistance === undefined
            ? {}
            : { minimumTargetDistance: target.minimumTargetDistance })
    };
}
/** @internal Validate, strip semantic fields and freeze a defensive numeric snapshot. */
export function freezeInteractionTarget(target) {
    const copy = copyInteractionTarget(target);
    if (!copy)
        return null;
    Object.freeze(copy.coordinate);
    Object.freeze(copy.screenPosition);
    return Object.freeze(copy);
}
/** Captures only hard view configuration, never a camera pose or derived clip matrix. */
export function getInteractionTargetStructure(props) {
    const view = props._view;
    const viewProps = view?.props || {};
    const result = { type: view?.constructor };
    for (const key of [
        'canvasId',
        'padding',
        'repeat',
        'nearZMultiplier',
        'farZMultiplier',
        'nearZ',
        'farZ',
        'near',
        'far',
        'projectionMatrix',
        'fovy',
        'altitude',
        'orthographic',
        'modelMatrix',
        'worldOffset',
        'up',
        'focalDistance',
        'legacyMeterSizes',
        'rubberBand'
    ]) {
        const value = viewProps[key] ??
            props[key] ??
            (key === 'altitude'
                ? 1.5
                : ['rubberBand', 'legacyMeterSizes'].includes(key)
                    ? false
                    : undefined);
        result[key] = Array.isArray(value)
            ? [...value]
            : value && typeof value === 'object'
                ? { ...value }
                : value;
    }
    return result;
}
//# sourceMappingURL=interaction-target.js.map