// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
import LinearInterpolator from "./linear-interpolator.js";
import assert from "../utils/assert.js";
import isFiniteTuple from "../utils/is-finite-tuple.js";
import { lerp } from '@math.gl/core';
import { freezeInteractionTarget } from "../controllers/interaction-target.js";
function copyTransitionProps(props) {
    const result = {};
    for (const key in props) {
        const value = props[key];
        result[key] = Array.isArray(value) ? value.slice() : value;
    }
    return result;
}
function freezeTransitionProps(props) {
    const result = copyTransitionProps(props);
    for (const key in result) {
        if (Array.isArray(result[key])) {
            Object.freeze(result[key]);
        }
    }
    return Object.freeze(result);
}
/**
 * Linearly interpolates view state while delegating target-relative camera construction
 * and validation to a controller callback on every frame.
 *
 * The target contains numeric coordinates only and is copied before it is retained. When the
 * callback reports no solution, the exact last accepted frame is returned. Initialization seeds
 * that fallback from the already validated canonical start props. The `t = 0` frame reuses that
 * state without a redundant camera inverse; subsequent animated frames are resolved normally.
 */
export default class TargetNavigationInterpolator extends LinearInterpolator {
    constructor(options) {
        super({ transitionProps: options.transitionProps });
        this.lastAcceptedProps = null;
        const target = freezeInteractionTarget(options.target);
        assert(target, 'target coordinate and pixel must be finite; minimum target distance must be non-negative and finite');
        assert(!options.endScreenPosition || isFiniteTuple(options.endScreenPosition, 2), 'end screen position must be finite');
        assert(typeof options.resolveFrame === 'function', 'resolveFrame must be a function');
        this.target = target;
        this.endScreenPosition = Object.freeze([
            ...(options.endScreenPosition || options.target.screenPosition)
        ]);
        this.resolveFrame = options.resolveFrame;
    }
    initializeProps(startProps, endProps) {
        const result = super.initializeProps(startProps, endProps);
        this.lastAcceptedProps = copyTransitionProps(result.start);
        return result;
    }
    interpolateProps(startProps, endProps, t) {
        const interpolatedProps = super.interpolateProps(startProps, endProps, t);
        if (!this.lastAcceptedProps) {
            this.lastAcceptedProps = copyTransitionProps(startProps);
        }
        if (t <= 0) {
            return this.lastAcceptedProps;
        }
        const context = {
            target: this.target,
            screenPosition: Object.freeze(lerp([...this.target.screenPosition], [...this.endScreenPosition], t)),
            progress: t,
            previousProps: freezeTransitionProps(this.lastAcceptedProps)
        };
        const resolvedFrame = this.resolveFrame(freezeTransitionProps(interpolatedProps), context);
        if (resolvedFrame) {
            this.lastAcceptedProps = copyTransitionProps(resolvedFrame);
        }
        return this.lastAcceptedProps;
    }
}
//# sourceMappingURL=target-navigation-interpolator.js.map