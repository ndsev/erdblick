// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
import LinearInterpolator from "./linear-interpolator.js";
import assert from "../utils/assert.js";
import { lerp } from '@math.gl/core';
const DEFAULT_TRANSITION_PROPS = {
    compare: ['longitude', 'latitude', 'zoom', 'bearing', 'pitch', 'position'],
    required: ['longitude', 'latitude', 'zoom']
};
function copyTransitionProps(props) {
    const result = {};
    for (const key in props) {
        const value = props[key];
        result[key] = Array.isArray(value) ? value.slice() : value;
    }
    return result;
}
function freezeTransitionProps(props) {
    const result = copyTransitionProps(props);
    for (const key in result) {
        if (Array.isArray(result[key])) {
            Object.freeze(result[key]);
        }
    }
    return Object.freeze(result);
}
function isFiniteTuple(value, length) {
    return (Array.isArray(value) &&
        value.length === length &&
        value.every(component => Number.isFinite(component)));
}
/**
 * Linearly interpolates map view state while delegating target-relative camera construction
 * and validation to a controller callback on every frame.
 *
 * The target contains numeric coordinates only and is copied before it is retained. When the
 * callback reports no solution, the exact last accepted frame is returned. Initialization seeds
 * that fallback from the already validated canonical start props. The `t = 0` frame reuses that
 * state without a redundant camera inverse; subsequent animated frames are resolved normally.
 */
export default class TargetNavigationInterpolator extends LinearInterpolator {
    constructor(options) {
        super({ transitionProps: options.transitionProps || DEFAULT_TRANSITION_PROPS });
        this.lastAcceptedProps = null;
        assert(isFiniteTuple(options.target.coordinate, 3), 'target coordinate must be finite');
        assert(isFiniteTuple(options.target.screenPosition, 2), 'target screen position must be finite');
        assert(options.target.minimumTargetDistance === undefined ||
            (Number.isFinite(options.target.minimumTargetDistance) &&
                options.target.minimumTargetDistance >= 0), 'minimum target distance must be non-negative and finite');
        const mode = options.mode || 'orbit';
        if (mode === 'orbit') {
            assert(Number.isFinite(options.startRadius) && Number(options.startRadius) > 0, 'start radius must be positive and finite');
        }
        assert(!options.endScreenPosition || isFiniteTuple(options.endScreenPosition, 2), 'end screen position must be finite');
        assert(typeof options.resolveFrame === 'function', 'resolveFrame must be a function');
        this.target = Object.freeze({
            coordinate: Object.freeze([...options.target.coordinate]),
            screenPosition: Object.freeze([...options.target.screenPosition]),
            ...(options.target.minimumTargetDistance === undefined
                ? {}
                : { minimumTargetDistance: options.target.minimumTargetDistance })
        });
        this.mode = mode;
        this.startRadius = options.mode === 'pan' ? null : options.startRadius;
        this.minimumRadius =
            mode === 'orbit' && options.target.minimumTargetDistance
                ? Math.min(options.startRadius, options.target.minimumTargetDistance)
                : 0;
        this.endScreenPosition = Object.freeze([
            ...(options.endScreenPosition || options.target.screenPosition)
        ]);
        this.resolveFrame = options.resolveFrame;
    }
    initializeProps(startProps, endProps) {
        const result = super.initializeProps(startProps, endProps);
        this.lastAcceptedProps = copyTransitionProps(result.start);
        return result;
    }
    interpolateProps(startProps, endProps, t) {
        const interpolatedProps = super.interpolateProps(startProps, endProps, t);
        const startZoom = startProps.zoom;
        const zoom = interpolatedProps.zoom;
        assert(Number.isFinite(startZoom), 'start zoom is required for target navigation transition');
        assert(Number.isFinite(zoom), 'interpolated zoom must be finite');
        if (!this.lastAcceptedProps) {
            this.lastAcceptedProps = copyTransitionProps(startProps);
        }
        if (t <= 0) {
            return this.lastAcceptedProps;
        }
        const contextBase = {
            target: this.target,
            screenPosition: Object.freeze(lerp([...this.target.screenPosition], [...this.endScreenPosition], t)),
            progress: t,
            previousProps: freezeTransitionProps(this.lastAcceptedProps)
        };
        const context = this.mode === 'pan'
            ? { ...contextBase, mode: 'pan' }
            : {
                ...contextBase,
                mode: 'orbit',
                radius: Math.max(this.startRadius * 2 ** (startZoom - zoom), this.minimumRadius)
            };
        const resolvedFrame = this.resolveFrame(freezeTransitionProps(interpolatedProps), context);
        if (resolvedFrame) {
            this.lastAcceptedProps = copyTransitionProps(resolvedFrame);
        }
        return this.lastAcceptedProps;
    }
}
//# sourceMappingURL=target-navigation-interpolator.js.map