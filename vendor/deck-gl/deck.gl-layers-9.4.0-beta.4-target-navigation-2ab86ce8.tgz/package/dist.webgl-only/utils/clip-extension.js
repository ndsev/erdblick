// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
const CLIP_MODE_GEOMETRY = 0;
const CLIP_MODE_INSTANCE = 1;
const source = null;
const clipExtension = {
    name: 'clip',
    source,
    props: {},
    uniforms: {},
    bindingLayout: [{ name: 'clip', group: 2 }],
    uniformTypes: {
        enabled: 'i32',
        mode: 'i32',
        bounds: 'vec4<f32>'
    },
    defaultUniforms: {
        enabled: 0,
        mode: CLIP_MODE_GEOMETRY,
        bounds: [0, 0, 1, 1]
    },
    getUniforms(props = {}) {
        const uniforms = {};
        if (props.enabled !== undefined) {
            uniforms.enabled = props.enabled ? 1 : 0;
        }
        if (props.mode !== undefined) {
            uniforms.mode = props.mode === 'instance' ? CLIP_MODE_INSTANCE : CLIP_MODE_GEOMETRY;
        }
        if (props.bounds !== undefined) {
            uniforms.bounds = props.bounds;
        }
        return uniforms;
    }
};
export default clipExtension;
//# sourceMappingURL=clip-extension.js.map