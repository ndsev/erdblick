// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
import { calculatePickingIndexes } from "./geojson-binary.js";
function createEmptyLayerProps() {
    return {
        points: {},
        lines: {},
        polygons: {},
        polygonsOutline: {}
    };
}
function getCoordinates(f) {
    return f.geometry.coordinates;
}
export function createLayerPropsFromFeatures(features, featuresDiff) {
    const layerProps = createEmptyLayerProps();
    const { pointFeatures, lineFeatures, polygonFeatures, polygonOutlineFeatures } = features;
    layerProps.points.data = pointFeatures;
    layerProps.points._dataDiff = featuresDiff.pointFeatures && (() => featuresDiff.pointFeatures);
    layerProps.points.getPosition = getCoordinates;
    layerProps.lines.data = lineFeatures;
    layerProps.lines._dataDiff = featuresDiff.lineFeatures && (() => featuresDiff.lineFeatures);
    layerProps.lines.getPath = getCoordinates;
    layerProps.polygons.data = polygonFeatures;
    layerProps.polygons._dataDiff =
        featuresDiff.polygonFeatures && (() => featuresDiff.polygonFeatures);
    layerProps.polygons.getPolygon = getCoordinates;
    layerProps.polygonsOutline.data = polygonOutlineFeatures;
    layerProps.polygonsOutline._dataDiff =
        featuresDiff.polygonOutlineFeatures && (() => featuresDiff.polygonOutlineFeatures);
    layerProps.polygonsOutline.getPath = getCoordinates;
    return layerProps;
}
export function createLayerPropsFromBinary(geojsonBinary) {
    // The binary data format is documented here
    // https://github.com/visgl/loaders.gl/blob/master/modules/gis/docs/api-reference/geojson-to-binary.md
    // It is the default output from the `MVTLoader` and can also be obtained
    // from GeoJSON by using the `geojsonToBinary` utility function.
    const layerProps = createEmptyLayerProps();
    const { points, lines, polygons } = geojsonBinary;
    const customPickingIndexes = calculatePickingIndexes(geojsonBinary);
    layerProps.points.data = {
        length: points.positions.value.length / points.positions.size,
        attributes: {
            ...points.attributes,
            getPosition: points.positions,
            /** Global feature id for the rendered point geometry. */
            rowIndexes: {
                size: 1,
                type: 'uint32',
                value: customPickingIndexes.points
            }
        },
        properties: points.properties,
        numericProps: points.numericProps,
        featureIds: points.featureIds
    };
    layerProps.lines.data = {
        length: lines.pathIndices.value.length - 1,
        startIndices: lines.pathIndices.value,
        attributes: {
            ...lines.attributes,
            getPath: lines.positions,
            /** Global feature id for the rendered path geometry. */
            rowIndexes: {
                size: 1,
                type: 'uint32',
                value: customPickingIndexes.lines
            }
        },
        properties: lines.properties,
        numericProps: lines.numericProps,
        featureIds: lines.featureIds
    };
    layerProps.lines._pathType = 'open';
    const vertexCount = polygons.positions.value.length / polygons.positions.size;
    const vertexValid = Array(vertexCount).fill(1);
    for (const index of polygons.primitivePolygonIndices.value) {
        vertexValid[index - 1] = 0;
    }
    layerProps.polygons.data = {
        length: polygons.polygonIndices.value.length - 1,
        startIndices: polygons.polygonIndices.value,
        attributes: {
            ...polygons.attributes,
            getPolygon: polygons.positions,
            instanceVertexValid: {
                size: 1,
                value: new Uint16Array(vertexValid)
            },
            /** Global feature id for the rendered polygon geometry. */
            rowIndexes: {
                size: 1,
                type: 'uint32',
                value: customPickingIndexes.polygons
            }
        },
        properties: polygons.properties,
        numericProps: polygons.numericProps,
        featureIds: polygons.featureIds
    };
    layerProps.polygons._normalize = false;
    if (polygons.triangles) {
        layerProps.polygons.data.attributes.indices = polygons.triangles.value;
    }
    layerProps.polygonsOutline.data = {
        length: polygons.primitivePolygonIndices.value.length - 1,
        startIndices: polygons.primitivePolygonIndices.value,
        attributes: {
            ...polygons.attributes,
            getPath: polygons.positions,
            /** Global feature id for the rendered polygon outline geometry. */
            rowIndexes: {
                size: 1,
                type: 'uint32',
                value: customPickingIndexes.polygons
            }
        },
        properties: polygons.properties,
        numericProps: polygons.numericProps,
        featureIds: polygons.featureIds
    };
    layerProps.polygonsOutline._pathType = 'open';
    return layerProps;
}
//# sourceMappingURL=geojson-layer-props.js.map