// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
export default /* wgsl */ null;
//# sourceMappingURL=path-layer.wgsl.js.map