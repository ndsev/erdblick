// deck.gl
// SPDX-License-Identifier: MIT
// Copyright (c) vis.gl contributors
export default /* wgsl */ null;
//# sourceMappingURL=point-cloud-layer.wgsl.js.map